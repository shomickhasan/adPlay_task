<?php 

namespace App\Enums;

enum Status:string
{
    case Active='Active';
    case Inactive='Inactive';
}