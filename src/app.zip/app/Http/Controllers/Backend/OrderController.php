<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    public function index(Request $request){
        $filters = $request->only(['search', 'status']);
        $orders = Order::filters($filters)->latest()->paginate(self::WEB_PAGINATOR_NUMBER)->withQueryString();
        return $request->ajax()
            ? view('backend.pages.orders.filter', compact('orders'))

            : view('backend.pages.orders.index', compact('orders'));
    }

    public function details($id){
        $order = Order::with('orderProducts')->findOrFail($id);

        return view('backend.pages.orders.details', compact('order'));
    }

    public function statusControl(Request $request)
    {
        try {
            $request->validate([
                'status' => 'required|integer'
            ]);
            $orderId = $request->id;
            $order = Order::findOrFail($orderId);
            $order->status = $request->status;
            $order->save();
            return response()->json([
                'success' => true,
                'message' => 'Order status updated successfully!',
                'new_status' => \App\Models\Order::ORDER_STATUSES[$order->status] ?? ''
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update order status. Error: ' . $e->getMessage()
            ], 500);
        }
    }






}
