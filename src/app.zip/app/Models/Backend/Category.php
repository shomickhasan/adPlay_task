<?php

namespace App\Models\Backend;

use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $fillable =['category_name', 'status','slug'];

    public function scopeOrderByDescId($query)
    {
        return $query->orderByDesc('id');
    }
    public function scopeOrderByAscId($query)
    {
        return $query->orderBy('id', 'asc');
    }
    public function scopeStatus($query, $status)
    {
        return $query->where('status', $status);
    }
    public function CreatedAtFormatted(): Attribute
    {
        return Attribute::make(
            get: fn () => Carbon::parse($this->created_at)->format('M d, Y, g:i A')
        );
    }
    public function UpdatedAtFormatted(): Attribute
    {
        return Attribute::make(
            get: fn () => Carbon::parse($this->updated_at)->format('M d, Y, g:i A')
        );
    }

    public function products()
    {
        return $this->hasMany(Product::class, 'cat_id');
    }


}
