

                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl">
                            <div class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
                                <div>
                                    <span class="custom-number">V 1.0</span> &nbsp;<span class="custom-number"> ©{{ date('Y') }} , All Rights Reserved | Built with</span> <i class="fa fa-heart text-danger"></i> By <a href="#" target="_blank_blank">Shakil & Shomick</a>
                            </div>
                        </div>
                    </footer>
                    <!-- / Footer -->