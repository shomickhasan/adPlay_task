<?php

namespace App\Http\Controllers\Frontend;

use App\Models\Backend\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    public function index()
    {
        $trendings = Product::with('productQuantitys')
            ->where('is_trending_product', 1)
            ->OrderByDescId()
            ->paginate(self::WEB_PAGINATOR_NUMBER)
            ->withQueryString();

        $featers = Product::with('productQuantitys')
            ->where('is_feater_product', 1)
            ->OrderByDescId()
            ->limit(3)
            ->get();

        $homeProducts = Product::with('productQuantitys')
            ->where('is_show_home', 1)
            ->OrderByDescId()
            ->get();




        return view('frontend.index',compact('trendings','featers',
                'homeProducts'));
    }
}
