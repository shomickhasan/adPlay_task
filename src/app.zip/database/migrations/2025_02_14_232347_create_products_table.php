<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cat_id');
            $table->string('product_name')->nullable();
            $table->string('slug')->nullable();
            $table->double('price')->nullable();
            $table->double('discount_price')->nullable();
            $table->longText('short_description')->nullable();
            $table->longText('long_description')->nullable();
            $table->longText('shipping_info')->nullable();
            $table->string('image')->nullable();
            $table->tinyInteger('stoke_status')->default(0)->nullable()->comment('0 for stock out 1 for in stock');
            $table->tinyInteger('is_feater_product')->default(0)->comment('o for yes 1 for no');
            $table->tinyInteger('is_trending_product')->default(0)->comment('o for yes 1 for no');
            $table->tinyInteger('status')->default(0)->comment('0 for active 1 for inactive');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
