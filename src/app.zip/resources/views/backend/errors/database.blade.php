
<!DOCTYPE html>
<html lang="en">
<head>
    @include('backend.includes.header');
</head>
<body>
    <div class="container">
        <div class="alert alert-danger">
            <h1>Database Connection</h1>
            <p>Sorry, we could not connect to Database Server at this moment.</p>
        </div>
    </div>
</body>
    @include('backend.includes.script')
</html>


