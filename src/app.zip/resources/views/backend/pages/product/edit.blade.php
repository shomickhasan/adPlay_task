@extends('backend.template.template')
@section('title', 'Edit Product')
@push('css')

@endpush
@section('main')

    <div class="row mb-2">
        <div class="col">
            <h4 class="py-3 mb-4 fs-5 d-inline">
                <span class="text-muted fw-light">Administration /</span>
                <span class="heading-color">Edit Product</span>
            </h4>
        </div>
        <div class="col text-end">
            <a href="{{ route('product.index') }}" class="btn btn-primary me-sm-3 me-1 waves-effect waves-light">
                <i class="ti ti-arrow-left me-sm-1 ti-xs"></i> All Products
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-10 m-auto">
            <div class="card mb-4">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">Edit Product</h5>
                </div>
                <div class="card-body">
                    <form id="product-form" method="POST" action="{{ route('product.update', $product->id) }}" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="row g-3">
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="cat-id">Category</label>
                                    <div class="col-sm-9">
                                        <select name="cat_id" class="form-control @error('cat_id') is-invalid @enderror" id="cat-id">
                                            <option value="">Select Category</option>
                                            @foreach($categories as $category)
                                                <option value="{{ $category->id }}" {{ $product->cat_id == $category->id ? 'selected' : '' }}>
                                                    {{ $category->category_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('cat_id')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="product-name">Product Name</label>
                                    <div class="col-sm-9">
                                        <input name="product_name" type="text" class="form-control @error('product_name') is-invalid @enderror"
                                               id="product-name" placeholder="Product Name" value="{{ old('product_name', $product->product_name) }}" />
                                        @error('product_name')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="min-price"> Price</label>
                                    <div class="col-sm-9">
                                        <input name="price" type="number" class="form-control @error('price') is-invalid @enderror"
                                               id="min-price" placeholder=" Price" value="{{ old('price', $product->price) }}" />
                                        @error('price')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="max-price">Discount Price</label>
                                    <div class="col-sm-9">
                                        <input name="discount_price" type="number" class="form-control @error('discount_price') is-invalid @enderror"
                                               id="max-price" placeholder="Maximum Price" value="{{ old('discount_price', $product->discount_price) }}" />
                                        @error('discount_price')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3" id="quantity-price-wrapper">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="quantity-price">Quantity & Price</label>
                                    <div class="col-sm-9">
                                        <div id="quantity-price-container">
                                            @foreach($product->productQuantitys as $index => $quantity)
                                            <div class="row mb-3 quantity-group align-items-center" data-index="{{ $index }}">
                                                <input type="hidden" value="{{ $quantity->id }}" name="qunatity_id[]">
                                        
                                                <div class="col-sm-4">
                                                    <input type="text" name="quantities[]" class="form-control @error('quantities.*') is-invalid @enderror"
                                                           placeholder="Enter Quantity" value="{{ old('quantities.'.$index, $quantity->quantity) }}" />
                                                    @error('quantities.*')
                                                        <p class="text-danger">{{ $message }}</p>
                                                    @enderror
                                                </div>
                                        
                                                <div class="col-sm-4">
                                                    <input type="text" name="prices[]" class="form-control @error('prices.*') is-invalid @enderror"
                                                           placeholder="Enter Price" value="{{ old('prices.'.$index, $quantity->price) }}" />
                                                    @error('prices.*')
                                                        <p class="text-danger">{{ $message }}</p>
                                                    @enderror
                                                </div>
                                        
                                                <div class="col-sm-2">
                                                    @if($quantity->status)
                                                        <span class="badge bg-success">Active</span>
                                                    @else
                                                        <span class="badge bg-secondary">Inactive</span>
                                                    @endif
                                                </div>
                                        
                                                <div class="col-sm-2">
                                                    <button type="button"
                                                            class="btn btn-sm btn-outline-primary toggle-status-btn"
                                                            data-id="{{ $quantity->id }}"
                                                            data-status="{{ $quantity->status }}">
                                                        {{ $quantity->status ? 'Deactivate' : 'Activate' }}
                                                    </button>
                                                </div>
                                            </div>
                                        @endforeach                                        
                                        </div>
                                        <button type="button" class="btn btn-success add-more">Add More</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="short-description">Short Description</label>
                                    <div class="col-sm-9">
                                        <textarea name="short_description" class="form-control @error('short_description') is-invalid @enderror"
                                                  id="summernoteTwo" placeholder="Short Description">{{ old('short_description', $product->short_description) }}</textarea>
                                        @error('short_description')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="long-description">Long Description</label>
                                    <div class="col-sm-9">
                                        <textarea name="long_description" class="form-control @error('long_description') is-invalid @enderror"
                                                  id="summernoteThree" placeholder="Long Description">{{ old('long_description', $product->long_description) }}</textarea>
                                        @error('long_description')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="shipping-info">Shipping Info</label>
                                    <div class="col-sm-9">
                                        <textarea name="shipping_info" class="form-control @error('shipping_info') is-invalid @enderror"
                                                  id="summernotefour" placeholder="Shipping Info">{{ old('shipping_info', $product->shipping_info) }}</textarea>
                                        @error('shipping_info')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3 image-div">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="image">Image</label>
                                    <div class="col-sm-9">
                                        <input name="image" type="file" class="form-control @error('image') is-invalid @enderror"
                                               id="image" />
                                        @error('image')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3"></div>
                            <div class="col-sm-8 mt-5" style="height: 70px;width: 100px;">
                                @if(isset($product->image) && !empty($product->image))
                                    <img class="img-responsive image-show" src="{{ Storage::url($product->image) }}"  alt="" style="height:100%;width: 100%;"/>
                                @else
                                    <img class="img-responsive image-show" src="{{asset('image/no-image-uploded-2.png')}}"  alt="" style="height:100%;width: 100%;"/>
                                @endif

                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="stoke-status">Stock Status</label>
                                    <div class="col-sm-9 d-inline-block">
                                        <div class="vs-radio-con me-3">
                                            <input type="radio" name="stoke_status" value="1" class="@error('stoke_status') is-invalid @enderror"
                                                {{ old('stoke_status', $product->stoke_status) == '1' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">In Stock</span>
                                        </div>
                                        <div class="vs-radio-con">
                                            <input type="radio" name="stoke_status" value="0" class="@error('stoke_status') is-invalid @enderror"
                                                {{ old('stoke_status', $product->stoke_status) == '0' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">Out of Stock</span>
                                        </div>
                                        @error('stoke_status')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="status">Status</label>
                                    <div class="col-sm-9 d-inline-block">
                                        <div class="vs-radio-con me-3">
                                            <input type="radio" name="status" value="1" class="@error('status') is-invalid @enderror"
                                                {{ old('status', $product->status) == '1' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">Active</span>
                                        </div>
                                        <div class="vs-radio-con">
                                            <input type="radio" name="status" value="0" class="@error('status') is-invalid @enderror"
                                                {{ old('status', $product->status) == '0' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">Inactive</span>
                                        </div>
                                        @error('status')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="is_feater_product">Is Feater Product?</label>
                                    <div class="col-sm-9 d-inline-block">
                                        <div class="vs-radio-con me-3">
                                            <input type="radio" name="is_feater_product" value="1" class="@error('is_feater_product') is-invalid @enderror"
                                                {{ old('is_feater_product', $product->is_feater_product) == '1' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">Yes</span>
                                        </div>
                                        <div class="vs-radio-con">
                                            <input type="radio" name="is_feater_product" value="0" class="@error('is_feater_product') is-invalid @enderror"
                                                {{ old('is_feater_product', $product->is_feater_product) == '0' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">No</span>
                                        </div>
                                        @error('is_feater_product')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="is_trending_product">Is Trending Product?</label>
                                    <div class="col-sm-9 d-inline-block">
                                        <div class="vs-radio-con me-3">
                                            <input type="radio" name="is_trending_product" value="1" class="@error('is_trending_product') is-invalid @enderror"
                                                {{ old('is_trending_product', $product->is_trending_product) == '1' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                             </span>
                                            <span class="">Yes</span>
                                        </div>
                                        <div class="vs-radio-con">
                                            <input type="radio" name="is_trending_product" value="0" class="@error('is_trending_product') is-invalid @enderror"
                                                {{ old('is_trending_product', $product->is_trending_product) == '0' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                             </span>
                                            <span class="">No</span>
                                        </div>
                                        @error('is_trending_product')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="is_show_home">Show on Home Page?</label>
                                    <div class="col-sm-9 d-inline-block">
                                        <div class="vs-radio-con me-3">
                                            <input type="radio" name="is_show_home" value="1" class="@error('is_show_home') is-invalid @enderror"
                                                {{ old('is_show_home', $product->is_show_home) == '1' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">Yes</span>
                                        </div>
                                        <div class="vs-radio-con">
                                            <input type="radio" name="is_show_home" value="0" class="@error('is_show_home') is-invalid @enderror"
                                                {{ old('is_show_home', $product->is_show_home) == '0' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">No</span>
                                        </div>
                                        @error('is_show_home')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <div class="row justify-content-end">
                                    <div class="col-sm-12">
                                        <button type="submit" class="btn btn-primary me-sm-3 me-1 waves-effect waves-light">Update</button>
                                        <a href="{{ route('product.index') }}" class="btn btn-label-secondary waves-effect">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
@push('script')
<script>
    $(document).ready(function () {
        // Add new Quantity & Price row
        $('.add-more').click(function () {
            var index = $('#quantity-price-container .quantity-group').length;
            var newRow = `
                <div class="row mb-3 quantity-group" data-index="${index}">
                    <div class="col-sm-5">
                        <input type="text" name="quantities[]" class="form-control" placeholder="Enter Quantity" />
                        <p class="text-danger quantity-error"></p> <!-- Placeholder for error message -->
                    </div>
                    <div class="col-sm-5">
                        <input type="text" name="prices[]" class="form-control" placeholder="Enter Price" />
                         <p class="text-danger quantity-error"></p> <!-- Placeholder for error message -->
                    </div>
                    <div class="col-sm-2">
                        <button type="button" class="btn btn-danger remove-quantity-price">-</button>
                    </div>
                </div>
            `;
            $('#quantity-price-container').append(newRow);
        });
    
        // Remove Quantity & Price row
        $(document).on('click', '.remove-quantity-price', function () {
            $(this).closest('.quantity-group').remove();
        });

            $(document).on('click', '.quantity-delete', function () {
                var quantityId = $(this).data('id'); // Get the quantity ID from the button's data attribute
                var row = $(this).closest('.quantity-group'); // Get the parent row for the quantity
        
                // Confirmation prompt using Swal
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to delete this quantity record!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel',
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Send AJAX request to delete the quantity record
                        $.ajax({
                            url: '/admin/products/quantity/' + quantityId, // The URL to delete the quantity
                            type: 'DELETE',
                            data: {
                                _token: '{{ csrf_token() }}', // Include CSRF token for security
                            },
                            success: function(response) {
                                // If successful, remove the row from the UI
                                row.remove();
                                Swal.fire(
                                    'Deleted!',
                                    'The quantity record has been deleted.',
                                    'success'
                                );
                            },
                            error: function(error) {
                                // Show error message if deletion fails
                                Swal.fire(
                                    'Error!',
                                    'There was an error deleting the quantity record.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });

            $("#product-form").submit(function (event) {
                event.preventDefault();
            
                let formData = new FormData(this);
            
                $.ajax({
                    url: $(this).attr('action'),
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function () {
                        $(".text-danger").remove(); // Remove previous error messages
                        $(".is-invalid").removeClass("is-invalid"); // Remove invalid class
                    },
                    success: function (response) {
                        if (response.success) {
                            toastr.success(response.message, "Success!");
                            $("#product-form")[0].reset(); // Reset form
                            setTimeout(() => {
                                window.location.href = "{{ route('product.index') }}";
                            }, 2000);
                        } else {
                            toastr.error(response.message, "Error!");
                        }
                    },
                    error: function (xhr) {
                        if (xhr.status === 422) {
                            let errors = xhr.responseJSON.errors;
                            $.each(errors, function (field, messages) {
                                let input = $('[name="' + field + '"]');
                                if (field.startsWith('quantities') || field.startsWith('prices')) {
                                    
                                    // Extract the index from the field name (quantities.0, prices.0, etc.)
                                    let index = field.split('.').pop(); // Get index from quantities.0 or prices.0
                                    
                                    // Dynamically find the correct input for quantities and prices
                                    input = $('[name="' + field + '"]');
                                    input.addClass("is-invalid");
                    
                                    // Find the parent div to append the error message
                                    let parentDiv = input.closest('.quantity-group').find('.col-sm-4'); 
                                    parentDiv.append('<p class="text-danger">' + messages[0] + "</p>");
                                    console.log(messages[0]);
                                }
                                // Check if it's a radio button group
                                if (input.attr("type") === "radio") {
                                    let parentDiv = input.closest(".col-sm-9"); // Find the nearest wrapper div
                                    if (parentDiv.find(".text-danger").length === 0) {
                                        parentDiv.append('<p class="text-danger">' + messages[0] + "</p>");
                                    }
                                } else {
                                    input.addClass("is-invalid");
                                    input.after('<p class="text-danger">' + messages[0] + "</p>");
                                }
                            });
                        } else {
                            toastr.error("Something went wrong. Please try again.", "Error!");
                        }
                    },
                });
            });
        });
</script>
<script>
    $(document).on('click', '.toggle-status-btn', function () {
        var button = $(this);
        var quantityId = button.data('id');
        var currentStatus = button.data('status');

        Swal.fire({
            title: 'Are you sure?',
            text: currentStatus ? "This will deactivate the quantity." : "This will activate the quantity.",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#aaa',
            confirmButtonText: 'Yes',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '/admin/products/quantity/' + quantityId + '/toggle-status',
                    type: 'PATCH',
                    data: {
                        _token: '{{ csrf_token() }}',
                    },
                    success: function (response) {
                        Swal.fire('Updated!', response.message, 'success').then(() => {
                            // Option 1: reload whole page
                            {{--  location.reload();  --}}
                            $('#quantity-price-container').load(location.href + ' #quantity-price-container > *');
                            // Option 2 (optional): just update text/status/button without reload
                            // button.data('status', 1 - currentStatus);
                            // button.text(currentStatus ? 'Activate' : 'Deactivate');
                        });
                    },
                    error: function () {
                        Swal.fire('Error!', 'Unable to change status.', 'error');
                    }
                });
            }
        });
    });
</script>

@endpush

