@extends('frontend.main')
@section('ftitle', 'About Us')
@section('frontend')

<!-- page title area start -->
<section class="page__title p-relative d-flex align-items-center" data-background="{{asset('/')}}frontend/assets/img/page-title/page-title-2.jpg">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="page__title-inner text-center">
                    <h1>About Us</h1>
                    <div class="page__title-breadcrumb">                                 
                        <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page"> About Us</li>
                        </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- page title area end -->

<!-- error area start -->
<section class="error__area pt-60 pb-100">
    <div class="container">
        <div class="col-xl-8 offset-xl-2 col-lg-8 offset-lg-2">
            <div class=" text-left">
                <h2>About Us</h2>
                <p>
                 Krishibid Bazaar Limited is one of the best private limited 
                 company in Bangladesh offering only brand products and providing home
                  delivery within Dhaka city like as fresh vegetables, fish, chicken and beef,
                   other fresh products. This company also serves all kind of food organic food, 
                   non-food product, grocery & daily essential products. We would like to ensure healthy
                    & happy life by providing wholesome quality food, quick delivery service and excellent 
                 shopping experience. By ensuring healthy life, we would like to make our consumers smile.
                </p>
                <p>
                   Krishibid Bazaar gains its fame by giving quality service
                    at the best level. People can reach Krishibid Bazaar through website 
                   (krishibidbazaar.com), Facebook (fb.com/krishibidbazaar.com.bd) and hotline numbers.
                </p>
                <p>
                   Krishibid Bazaar has started its journey from 2012.Till date, Krishibid Bazaar has served more 
                   than 45 thousand+ unique consumers. People can collect their products from its outlets as well.
                </p>
                
            </div>
        </div>
    </div>
</section>
<!-- error area end -->
@endsection