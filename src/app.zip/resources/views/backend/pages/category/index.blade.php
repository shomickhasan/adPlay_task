@extends('backend.template.template')
@section('title',  "Categories")
@section('main')
    <h4 class="py-3 mb-4 fs-5 ">
        <span class="text-muted fw-light">Adminstration/</span>
        <span class="heading-color">Categories</span>
    </h4>
    <div class="card">
        <div class="card-header">
            <a href="{{ route('category.create') }}" style="color: white;">
                <button class="btn btn-secondary add-new btn-primary waves-effect waves-light" tabindex="0" aria-controls="DataTables_Table_0" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasAddUser">
                <span>
                    <i class="ti ti-plus me-0 me-sm-1 ti-xs"></i>
                    <span class="d-none d-sm-inline-block">Add New Category</span>
                </span>
                </button>
            </a>
            {{--<div class="btn-group">
                <button  class="btn filter-btn btn-secondary add-new btn-primary waves-effect waves-light"><span> <i class="ti ti-filter me-0 me-sm-1 ti-xs"></i>&nbsp; Filter </span></button>
            </div>--}}
        </div>
        <div class="card-body">
            <form class="dt_adv_search filter" method="get" action="{{ route('category.index') }}" id="searchForm"  style="display: none">
            </form>
        </div>
        <div id="filterTable">
            <div class="card-datatable table-responsive">
                <table class="datatables-products table item_table table-hover">
                    <thead class="border-top">
                    <tr>
                        <th>#</th>
                        <th>Category Name</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        @foreach($categories as $category)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $category->category_name }}</td>
                                <td>
                                    @if ($category->status == 1)
                                        <span class="badge bg-label-success" text-capitalized="">Active</span>
                                    @else
                                        <span class="badge bg-label-danger" text-capitalized="">Inactive</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-inline-block text-nowrap">
                                        <a href="{{route('category.edit',$category->id)}}">
                                            <button class="btn btn-sm btn-icon edit-i"><i class="ti ti-edit"></i></button>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mb-2">
                {{ $categories->links('backend.pagination.custome') }}
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script>
        $('#search').on('click', function() {
            var formData = $('#searchForm').serialize();
            $.ajax({
                type: 'GET',
                url: '{{ route('users.index') }}',
                data: formData,
                success: function(response) {
                    $('#filterTable').html(response);
                },
                error: function(error) {

                }
            });
        });
    </script>

@endpush

