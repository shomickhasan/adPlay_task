@extends('frontend.main')
@section('ftitle', 'About Us')
@section('frontend')
@push("css")

@endpush
{{--  <!--<section class="page__title p-relative d-flex align-items-center" data-background="{{asset('/')}}frontend/assets/img/page-title/page-title-2.jpg">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-xl-12">-->
<!--                <div class="page__title-inner text-center">-->
<!--                    <h1>About Us</h1>-->
<!--                    <div class="page__title-breadcrumb">-->
<!--                        <nav aria-label="breadcrumb">-->
<!--                            <ol class="breadcrumb justify-content-center">-->
<!--                                <li class="breadcrumb-item"><a href="">Home</a></li>-->
<!--                                <li class="breadcrumb-item active" aria-current="page"> About Us</li>-->
<!--                            </ol>-->
<!--                        </nav>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</section>-->  --}}

<section class="container mt-5">
    <div class="about-section">
        <h2 class="about-title">Welcome to Haorerbazar.com</h2>
        <p class="about-text">
            Welcome to Haorerbazar.com, your trusted online marketplace for the finest live and dried fish, organically sourced from the pristine waters of Kishoreganj. At Haorerbazar, we are passionate about providing our customers with the freshest and highest quality fish, ensuring that every product is free from harmful chemicals and rich in natural nutrients.
            Our journey began with a commitment to sustainability and a desire to bring the best of Kishoreganj's aquatic bounty to households across Bangladesh. We take pride in our meticulous sourcing process, selecting only the best fish from the haors, known for their clean and nutrient-rich waters.
        </p>


            <h2 class="about-title">Haorerbazar's Fish Offerings</h2>
            <p class="about-text">
                Haorerbazar offers a diverse selection of fish to cater to various tastes and preferences. Their inventory includes:
            </p>

            <ul class="fish-list">
                <li><strong>Live Fish:</strong> Freshly caught from the haors, ensuring the highest quality and taste.</li>
                <li><strong>Dry Fish:</strong> Perfect for traditional recipes, packed with nutrients and flavor.</li>
                <li><strong>Organic Fish:</strong> Raised in natural environments without harmful chemicals, providing a healthy option for consumers.</li>
            </ul>
        <br>

        <p class="about-text">
            At Haorerbazar, we believe in maintaining the highest standards of freshness and quality. Our efficient delivery system, combined with temperature-controlled packaging, ensures that you receive your fish in perfect condition, every time.
            Join us in our mission to promote healthy eating and sustainable sourcing. Trust Haorerbazar for all your fish needs and experience the true taste of purity and health.
            Thank you for choosing Haorerbazar. We look forward to serving you!
        </p>

    </div>
</section>
<section class="container mt-5">
    <div class="about-section">
        <h2 class="about-title">Haorerbazar.com-এ আপনাকে স্বাগতম</h2>
        <p class="about-text">
            কিশোরগঞ্জের বিশুদ্ধ জল থেকে জৈবভাবে সংগ্রহ করা সেরা জীবন্ত এবং শুকনো মাছের জন্য আপনার বিশ্বস্ত অনলাইন বাজার Haorerbazar.com-এ আপনাকে স্বাগতম। হাওরেরবাজারে, আমরা আমাদের গ্রাহকদের তাজা এবং সর্বোচ্চ মানের মাছ সরবরাহ করতে আগ্রহী, প্রতিটি পণ্য ক্ষতিকারক রাসায়নিক মুক্ত এবং প্রাকৃতিক পুষ্টিতে সমৃদ্ধ তা নিশ্চিত করে।
            আমাদের যাত্রা শুরু হয়েছিল টেকসইতার প্রতি অঙ্গীকার এবং বাংলাদেশের বিভিন্ন পরিবারের কাছে কিশোরগঞ্জের জলজ সম্পদের সেরাটি পৌঁছে দেওয়ার আকাঙ্ক্ষা নিয়ে। আমরা আমাদের সূক্ষ্ম সোর্সিং প্রক্রিয়ায় গর্বিত, শুধুমাত্র হাওর থেকে সেরা মাছ নির্বাচন করে, যা তাদের পরিষ্কার এবং পুষ্টিকর সমৃদ্ধ জলের জন্য পরিচিত।
        </p>

        <div class="about-section">
            <h2 class="about-title">হাওরেরবাজারের মাছের অফার</h2>
            <p class="about-text">
                হাওরেরবাজার বিভিন্ন স্বাদ এবং পছন্দ পূরণের জন্য মাছের বৈচিত্র্যময় নির্বাচন অফার করে। তাদের তালিকার মধ্যে রয়েছে:
            </p>

            <ul class="fish-list">
                <li><strong>জীবন্ত মাছ:</strong> হাওর থেকে তাজা ধরা, সর্বোচ্চ মানের এবং স্বাদ নিশ্চিত করে।</li>
                <li><strong>শুকনো মাছ:</strong> ঐতিহ্যবাহী রেসিপির জন্য উপযুক্ত, পুষ্টি এবং স্বাদে ভরপুর।</li>
                <li><strong>জৈব মাছ:</strong> ক্ষতিকারক রাসায়নিক ছাড়াই প্রাকৃতিক পরিবেশে বেড়ে ওঠা, গ্রাহকদের জন্য একটি স্বাস্থ্যকর বিকল্প প্রদান করে।</li>
            </ul>
        </div>
        <p class="about-text">
            হাওরেরবাজারে, আমরা সতেজতা এবং মানের সর্বোচ্চ মান বজায় রাখতে বিশ্বাস করি। আমাদের দক্ষ ডেলিভারি সিস্টেম, তাপমাত্রা-নিয়ন্ত্রিত প্যাকেজিংয়ের সাথে মিলিত, নিশ্চিত করে যে আপনি প্রতিবার নিখুঁত অবস্থায় আপনার মাছ পাবেন।
            স্বাস্থ্যকর খাবার এবং টেকসই সোর্সিং প্রচারের লক্ষ্যে আমাদের সাথে যোগ দিন। আপনার সমস্ত মাছের চাহিদার জন্য হাওরেরবাজারে বিশ্বাস করুন এবং বিশুদ্ধতা এবং স্বাস্থ্যের প্রকৃত স্বাদ উপভোগ করুন।
            হাওরেরবাজার বেছে নেওয়ার জন্য আপনাকে ধন্যবাদ। আমরা আপনাকে সেবা দেওয়ার জন্য উন্মুখ!
        </p>
    </div>
</section>





@endsection
