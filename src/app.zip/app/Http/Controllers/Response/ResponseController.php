<?php

namespace App\Http\Controllers\Response;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\District;

class ResponseController extends Controller
{
    
}
