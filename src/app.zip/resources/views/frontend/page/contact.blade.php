@extends('frontend.main')
@section('ftitle', 'Contact')
@section('frontend')
@push('css')
    <style>
        .contact-info .contact-title {
            font-size: 2rem;
            font-weight: bold;
            color: #343a40;
        }

        .contact-item {
            background-color: #f8f9fa;
            transition: all 0.3s ease;
        }

        .contact-item:hover {
            background-color: #e9ecef;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .contact-item h5 {
            font-size: 1.1rem;
            color: #495057;
        }

        .contact-item p {
            font-size: 1rem;
            color: #6c757d;
        }

        .contact-item i {
            color: #007bff;
            width: 40px;
            height: 40px;
        }

        .contact-item div {
            flex: 1;
        }
    </style>
@endpush
<!-- page title area start -->
{{--  <!--<section class="page__title p-relative d-flex align-items-center" data-background="{{asset('/')}}frontend/assets/img/page-title/page-title-2.jpg">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-xl-12">-->
<!--                <div class="page__title-inner text-center">-->
<!--                    <h1>Contact Us</h1>-->
<!--                    <div class="page__title-breadcrumb">-->
<!--                        <nav aria-label="breadcrumb">-->
<!--                        <ol class="breadcrumb justify-content-center">-->
<!--                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>-->
<!--                            <li class="breadcrumb-item active" aria-current="page"> Contact</li>-->
<!--                        </ol>-->
<!--                        </nav>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</section>-->  --}}
<!-- page title area end -->

<!-- contact area start -->
<section class="container mt-5 mb-5">
    <div class="contact-info">
        <div class="row justify-content-center m-5">
            <div class="col-md-8">
                <!-- Address Row -->
                <div class="contact-item mb-4 p-3 border rounded shadow">
                    <div class="d-flex align-items-center">
                        <i class="fa fa-map-marker fa-2x text-primary mr-4"></i>
                        <div>
                            <h5 class="mb-1"><strong>Address:</strong></h5>
                            <p class="mb-0">Kishoreganj Sadar</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <!-- Phone Row -->
                <div class="contact-item mb-4 p-3 border rounded shadow">
                    <div class="d-flex align-items-center">
                        <i class="fa fa-phone fa-2x text-success mr-4"></i>
                        <div>
                            <h5 class="mb-1"><strong>Phone:</strong></h5>
                            <p class="mb-0"><a href="tel:+8801711742983" class="text-decoration-none text-dark">+880 1711-742983</a></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <!-- Email Row -->
                <div class="contact-item mb-4 p-3 border rounded shadow">
                    <div class="d-flex align-items-center">
                        <i class="fa fa-envelope fa-2x text-danger mr-4"></i>
                        <div>
                            <h5 class="mb-1"><strong>Email:</strong></h5>
                            <p class="mb-0"><a href="mailto:contact@Haorerbazar.com" class="text-decoration-none text-dark">contact@Haorerbazar.com</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- contact area end -->

<!-- contact map area start -->
<section class="contact__map">
    <div class="container-fluid p-0">
        <div class="row gx-0">
            <div class="col-xl-12">
                <div class="contact__map-wrapper p-relative">
                    <iframe src="https://maps.google.com/maps?hl=en&amp;q=Dhaka+()&amp;ie=UTF8&amp;t=&amp;z=10&amp;iwloc=B&amp;output=embed"></iframe>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- contact map area end -->

<!-- subscribe area start -->
{{--<section class="subscribe__area pb-100">
    <div class="container">
        <div class="subscribe__inner subscribe__inner-2 pt-95">
            <div class="row">
                <div class="col-xl-8 offset-xl-2">
                    <div class="subscribe__content text-center">
                        <h2>Get Discount Info</h2>
                        <p>Subscribe to the Outstock mailing list to receive updates on new arrivals, special offers and other discount information.</p>
                        <div class="subscribe__form">
                            <form action="#">
                                <input type="email" placeholder="Subscribe to our newsletter...">
                                <button class="os-btn os-btn-2 os-btn-3">subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>--}}
@endsection
