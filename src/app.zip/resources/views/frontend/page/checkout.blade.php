@extends('frontend.main')
@section('ftitle', 'Checkout')
@section('frontend')
@push('css')
    <style>

        label.form-label.text-label-color {
            font-weight: 600;
            color: #000;
        }
    </style>
@endpush

<!-- page title area start -->
{{--  <!--<section class="page__title p-relative d-flex align-items-center" data-background="">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-xl-12">-->
<!--                <div class="page__title-inner text-center">-->
<!--                    <h1>Checkout</h1>-->
<!--                    <div class="page__title-breadcrumb">-->
<!--                        <nav aria-label="breadcrumb">-->
<!--                        <ol class="breadcrumb justify-content-center">-->
<!--                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>-->
<!--                            <li class="breadcrumb-item active" aria-current="page"> Checkout</li>-->
<!--                        </ol>-->
<!--                        </nav>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</section>-->  --}}
<!-- page title area end -->

<!-- coupon-area start -->
{{--<section class="coupon-area pt-100 pb-30">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="coupon-accordion">
                    <!-- ACCORDION START -->
                    <h3>Returning customer? <span id="showlogin">Click here to login</span></h3>
                    <div id="checkout-login" class="coupon-content">
                        <div class="coupon-info">
                            <p class="coupon-text">Quisque gravida turpis sit amet nulla posuere lacinia. Cras sed est
                                sit amet ipsum luctus.</p>
                            <form action="#">
                                <p class="form-row-first">
                                    <label>Username or email <span class="required">*</span></label>
                                    <input type="text" />
                                </p>
                                <p class="form-row-last">
                                    <label>Password <span class="required">*</span></label>
                                    <input type="text" />
                                </p>
                                <p class="form-row">
                                    <button class="os-btn os-btn-black" type="submit">Login</button>
                                    <label>
                                        <input type="checkbox" />
                                        Remember me
                                    </label>
                                </p>
                                <p class="lost-password">
                                    <a href="#">Lost your password?</a>
                                </p>
                            </form>
                        </div>
                    </div>
                    <!-- ACCORDION END -->
                </div>
            </div>
            <div class="col-md-6">
                <div class="coupon-accordion">
                    <!-- ACCORDION START -->
                    <h3>Have a coupon? <span id="showcoupon">Click here to enter your code</span></h3>
                    <div id="checkout_coupon" class="coupon-checkout-content">
                        <div class="coupon-info">
                            <form action="#">
                                <p class="checkout-coupon">
                                    <input type="text" placeholder="Coupon Code" />
                                    <button class="os-btn os-btn-black" type="submit">Apply Coupon</button>
                                </p>
                            </form>
                        </div>
                    </div>
                    <!-- ACCORDION END -->
                </div>
            </div>
        </div>
    </div>
</section>--}}
<!-- coupon-area end -->
<!-- checkout-area start -->
<section class="checkout-area pb-70">
    <div class="container">
        <form action="{{route('order.store')}}" method="post">
            @csrf
            <div class="row">
                <div class="col-lg-6">
                    <div class="checkbox-form">
                        <h3>Billing Details</h3>
                            <div class="mb-3">
                                <label for="name" class="form-label text-label-color">আপনার নাম*</label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name') }}" required placeholder="আপনার নাম লিখুন">
                                @error('name') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>

                           {{-- <div class="mb-3">
                                <label for="email" class="form-label">Email (Optional)</label>
                                <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email') }}" placeholder="Enter your email">
                                @error('email') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>--}}

                            <div class="mb-3">
                                <label for="phone_number" class="form-label text-label-color">মোবাইল নাম্বার*</label>
                                <input type="tel" class="form-control @error('phone_number') is-invalid @enderror" id="phone_number" name="phone_number" value="{{ old('phone_number') }}" required placeholder="আপনার মোবাইল নাম্বারটি লিখুন">
                                @error('phone_number') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                            <div class="mb-3">
                                <label for="emergency_phone_number" class="form-label text-label-color">মোবাইল নাম্বার (অপশনাল)</label>
                                <input type="tel" class="form-control @error('phone_number') is-invalid @enderror" id="emergency_phone_number" name="emergency_phone_number" value="{{ old('emergency_phone_number') }}"  placeholder="আপনার পরিবারের যে কারো নাম্বার লিখুন">
                                @error('emergency_phone_number') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>

                            <div class="mb-3">
                                <label for="billing_address" class="form-label text-label-color">আপনার ঠিকানা লিখুন *</label>
                                <textarea class="form-control @error('billing_address') is-invalid @enderror" id="billing_address" name="billing_address" rows="2" required placeholder="বাসা নং, রোড নং, থানা জেলা">{{ old('billing_address') }}</textarea>
                                @error('billing_address') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>

                          {{--  <div class="mb-3">
                                <label for="shipping_address" class="form-label">Shipping Address</label>
                                <textarea class="form-control @error('shipping_address') is-invalid @enderror" id="shipping_address" name="shipping_address" rows="2" required placeholder="Enter shipping address">{{ old('shipping_address') }}</textarea>
                                @error('shipping_address') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>--}}
                        <div class="mb-3">
                            <label for="delivery_location" class="form-label text-label-color">ডেলিভারি লোকেশন</label>
                            <select class="form-select @error('delivery_location') is-invalid @enderror" id="delivery_location" name="delivery_location">
                                <option value="" disabled {{ old('delivery_location') ? '' : 'selected' }}>Select one</option>
                                <option value="Home Delivery" {{ old('delivery_location', 'Home Delivery') == 'Home Delivery' ? 'selected' : '' }}>হোম ডেলিভারি</option>
                                {{-- <option value="outside dhaka" {{ old('delivery_location') == 'outside dhaka' ? 'selected' : '' }}>Outside Dhaka</option> --}}
                            </select>
                            @error('delivery_location')
                            <div class="text-danger">{{ $message }}</div>
                            @enderror
                        </div>


                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="your-order mb-30 ">
                        <h3 class="mb-1">Your order</h3>
                        @if(session('error'))
                            <div class="alert alert-danger">{{ session('error') }}</div>
                        @endif
                        <div class="your-order-table table-responsive">
                            @if(!empty($cart))
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Subtotal</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($cart as $productId => $product)
                                        <tr>
                                            <td>{{ $product['name'] ?? 'N/A' }}</td>
                                            <td>{{ $product['quantity'] ?? 1 }}</td>
                                            <td class="price-color" style="
                                            color: #00A551;
                                            font-size: medium;
                                            font-weight: 500;
                                        ">৳{{ number_format($product['price'] ?? 0, 2) }}</td>
                                            <td class="price-color" style="
                                            color: #00A551;
                                            font-size: medium;
                                            font-weight: 500;
                                        ">৳{{ number_format(($product['price'] ?? 0) * ($product['quantity'] ?? 1), 2) }}</td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>Delivery Charge</td>
                                        <td id="deliveryCharge" style="
                                        color: #00A551;
                                        font-size: medium;
                                        font-weight: 500;
                                    ">৳ 0</td>
                                    </tr>
                                    <tr>
                                        <th colspan="3">Total</th>
                                        <th id="grandTotal" style="
                                        color:#00A551;
                                        font-size: medium;
                                        font-weight: 500;
                                    ">
                                            ৳{{ number_format(collect($cart)->sum(fn($item) => ($item['price'] ?? 0) * ($item['quantity'] ?? 1)), 2) }}
                                        </th>
                                    </tr>
                                    </tfoot>
                                </table>
                            @else
                                <p class="text-danger">Your cart is empty.</p>
                            @endif
                        </div>

                        <div class="payment-method">
                            <div class="mb-3">
                                <label for="payment_method" class="form-label">Payment Method</label>
                                <select class="form-select @error('payment_method') is-invalid @enderror" id="payment_method" name="payment_method" >
                                  {{--  <option value="" disabled {{ old('payment_method') ? '' : 'selected' }}>Select payment method</option>--}}
                                    <option value="1" {{ old('payment_method') == '1' ? 'selected' : '' }}>Cash On Delivery</option>
                                 {{--   <option value="2" {{ old('payment_method') == '2' ? 'selected' : '' }}>Online Payment</option>--}}
                                </select>
                                @error('payment_method') <div class="text-danger">{{ $message }}</div> @enderror
                            </div>
                            <div class="online_payment" style="display: none;">
                                <div class="mb-3">
                                    <label for="payment_method_name" class="form-label">Payment Method Name</label>
                                    <input type="text" class="form-control @error('payment_method_name') is-invalid @enderror" id="payment_method_name" name="payment_method_name" value="{{ old('payment_method_name') }}" placeholder="Enter payment method name">
                                    @error('payment_method_name') <div class="text-danger">{{ $message }}</div> @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="payment_account_number" class="form-label">Payment Account Number</label>
                                    <input type="text" class="form-control @error('payment_account_number') is-invalid @enderror" id="payment_account_number" name="payment_account_number" value="{{ old('payment_account_number') }}" placeholder="Enter payment account number">
                                    @error('payment_account_number') <div class="text-danger">{{ $message }}</div> @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="trax_id" class="form-label">Transaction ID</label>
                                    <input type="text" class="form-control @error('trax_id') is-invalid @enderror" id="trax_id" name="trax_id" value="{{ old('trax_id') }}" placeholder="Enter transaction ID">
                                    @error('trax_id') <div class="text-danger">{{ $message }}</div> @enderror
                                </div>
                            </div>

                            <div class="order-button-payment mt-20">
                                <button type="submit" class="os-btn os-btn-black">Place order</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>


@endsection
@push('script')
    <script>
        $(document).ready(function () {
            function toggleOnlinePayment() {
                if ($("#payment_method").val() == "2") {
                    $(".online_payment").show();
                    $("#payment_method_name, #payment_account_number, #trax_id").attr("required", true);
                } else {
                    $(".online_payment").hide();
                    $("#payment_method_name, #payment_account_number, #trax_id").removeAttr("required");
                }
            }
            toggleOnlinePayment();

            $("#payment_method").change(function () {
                toggleOnlinePayment();
            });

            function updateDeliveryCharge() {
                let deliveryCharge = $("#delivery_location").val() === "Home Delivery" ? 120 : 0;
                let totalAmount = {{ collect($cart)->sum(fn($item) => ($item['price'] ?? 0) * ($item['quantity'] ?? 1)) }};
                let grandTotal = totalAmount + deliveryCharge;

                $('#deliveryCharge').text('৳ ' + deliveryCharge);
                $('#grandTotal').text('৳ ' + grandTotal.toFixed(2));
            }

            // Ensure "Home Delivery" is selected if no option is pre-selected
            let deliverySelect = document.getElementById("delivery_location");
            if (!deliverySelect.value) {
                deliverySelect.value = "Home Delivery";
            }

            // Trigger change event to ensure calculation runs on page load
            $("#delivery_location").trigger("change");

            $("#delivery_location").on("change", function () {
                updateDeliveryCharge();
            });

            // Run calculation once on page load
            updateDeliveryCharge();
        });


    </script>

@endpush
