<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Response\ResponseController;
use App\Http\Requests\CategoryStoreRequest;
use App\Models\Backend\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    public function index( Request $request){
        $categories = Category::orderByDescId()
            ->paginate(self::WEB_PAGINATOR_NUMBER)->withQueryString();
        return view("backend.pages.category.index",compact('categories'));
    }

    public function create(Request $request){
        
        return view("backend.pages.category.create");
    }

    public function store(CategoryStoreRequest $request)
    {
        try {
            Category::create([
                'category_name' => $request->category_name,
                'slug' => Str::slug( $request->category_name),
                'status' => $request->status,
            ]);
            return redirect()->back()->with('message', 'User Create SuccessFully')->with('message', 'Category created successfully!');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', self::DEFAULT_ERROR_MESSAGE);
        }
    }

    public function edit($id)
    {
        $category = Category::findOrFail($id);
        return view('backend.pages.category.edit', compact('category'));
    }

    public function update(CategoryStoreRequest $request, $id)
    {
        try {
            $category = Category::findOrFail($id);
            $category->update([
                'category_name' => $request->category_name,
                'status' => $request->status,
            ]);
            return redirect()->route('category.index')->with('success', 'Category updated successfully!');
        } catch (\Exception $e) {

            return redirect()->back()->with('error', 'There was an error updating the category.');
        }
    }
}