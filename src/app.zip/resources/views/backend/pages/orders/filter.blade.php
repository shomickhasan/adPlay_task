<table class="datatables-products table item_table table-hover table-responsive">
    <thead>
    <tr>
        <th>#</th>
        <th>Order ID</th>
        <th>Customer Name</th>
        <th>Phone Number</th>
        <th>Total Amount</th>
        <th>Payment Method</th>
        <th>Delivery Location</th>
        <th>Actions</th>
        <th>Status</th> <!-- Moved Status Column -->
    </tr>
    </thead>
    <tbody>
    @forelse($orders as $key => $order)
        <tr>
            <td>{{ $orders->firstItem() + $key }}</td>
            <td>{{ $order->order_id }}</td>
            <td>{{ $order->name }}</td>
            <td>{{ $order->phone_number }}</td>
            <td>৳{{ number_format($order->total_amount, 2) }}</td>
            <td>
                @if($order->payment_method == 1)
                    Cash on Delivery
                @else
                    Online Payment
                @endif
            </td>
            <td>{{ ucfirst($order->delivery_location) }}</td>
            <td>
                <a href="{{route('orders.details',$order->id)}}" class="btn btn-sm btn-info">View</a>
            </td>
            <td> <!-- Status Button Here -->
                <div class="btn-group">
                    <button type="button" class="btn btn-sm dropdown-toggle waves-effect waves-light"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {{ \App\Models\Order::ORDER_STATUSES[$order->status] ?? 'Unknown' }}
                    </button>
                    <div class="dropdown-menu">
                        @foreach(\App\Models\Order::ORDER_STATUSES as $statusKey => $statusLabel)
                            @if($statusKey != $order->status)
                                <a href="#" class="dropdown-item change-status"
                                   data-order-id="{{ $order->id }}"
                                   data-status="{{ $statusKey }}"
                                   data-url="{{ route('orders.statusControl', $order->id) }}">
                                    {{ $statusLabel }}
                                </a>
                            @endif
                        @endforeach
                    </div>
                </div>
            </td>
        </tr>
    @empty
        <tr>
            <td colspan="9" class="text-center">No orders found.</td>
        </tr>
    @endforelse
    </tbody>
</table>
