<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductAddRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */

    public function rules()
    {
        return [
            'cat_id' => 'required|integer',
            'product_name' => 'required|string|max:255',
            'price' => 'required|numeric|min:0',
            'discount_price' => 'nullable|numeric|min:0',
            'short_description' => 'nullable|string',
            'long_description' => 'nullable|string',
            'shipping_info' => 'nullable|string',
            'stoke_status' => 'required|boolean',
            'status' => 'required|boolean',
            'is_feater_product' => 'required|boolean',
            'is_trending_product' => 'required|boolean',
            'is_show_home' => 'required|boolean',
            'image' => $this->isMethod('post') ? 'required|image|mimes:jpeg,png,jpg,gif|max:2048' : 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            // Ensure quantities are numeric and greater than or equal to 1
            'quantities.*' => 'nullable|string|min:1',
            
            // Ensure prices are numeric and greater than or equal to 0
            'prices.*' => 'nullable|numeric|min:0',
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            $quantities = request()->input('quantities', []);
            $prices = request()->input('prices', []);
    
            foreach ($quantities as $key => $quantity) {
                // Check if the quantity is provided but no price
                if (!empty($quantity) && empty($prices[$key])) {
                    $validator->errors()->add("prices.$key", 'Price is required when quantity is entered.');
                
                }
                // Check if the price is provided but no quantity
                if (!empty($prices[$key]) && empty($quantities[$key])) {
                    $validator->errors()->add("quantities.$key", 'Quantity is required when price is entered.');
                }
            }
        });
    }
    

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'cat_id.required' => 'The category ID is required.',
            'cat_id.integer' => 'The category ID must be an integer.',
            'product_name.required' => 'The product name is required.',
            'product_name.string' => 'The product name must be a string.',
            'product_name.max' => 'The product name may not be greater than 255 characters.',
            'min_price.required' => 'The minimum price is required.',
            'min_price.numeric' => 'The minimum price must be a number.',
            'min_price.min' => 'The minimum price must be at least 0.',
            'max_price.required' => 'The maximum price is required.',
            'max_price.numeric' => 'The maximum price must be a number.',
            'max_price.min' => 'The maximum price must be at least 0.',
            'short_description.required' => 'The short description is required.',
            'short_description.string' => 'The short description must be a string.',
            'long_description.required' => 'The long description is required.',
            'long_description.string' => 'The long description must be a string.',
            'shipping_info.required' => 'The shipping info is required.',
            'shipping_info.string' => 'The shipping info must be a string.',
            'image.required' => 'The product image is required.',
            'image.image' => 'The product image must be an image file.',
            'image.mimes' => 'The product image must be a file of type: jpeg, png, jpg, gif.',
            'image.max' => 'The product image may not be greater than 2048 kilobytes.',
            'stoke_status.required' => 'The stock status is required.',
            'stoke_status.boolean' => 'The stock status must be true or false.',
            'status.required' => 'The status is required.',
            'status.boolean' => 'The status must be true or false.',
        ];
    }
}
