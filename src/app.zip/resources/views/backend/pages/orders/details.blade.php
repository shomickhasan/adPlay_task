@extends('backend.template.template')
@section('title', "Order Details")
@section('main')
@push('css')
    <style>
        .quantity-badge {
            display: inline-block;
            background-color: #d8c144;
            color: #333;
            font-size: 12px;
            font-weight: bold;
            padding: 3px 8px;
            border-radius: 4px;
            margin-left: 5px;
        }
    </style>
@endpush
    <h4 class="py-3 mb-4 fs-5">
        <span class="text-muted fw-light">Administration /</span>
        <span class="heading-color">Order Details</span>
    </h4>

    <div class="card shadow-sm">
        @if(isset($order))
            <div class="card-body">
                <div class="row">
                    <!-- Customer Information -->
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0 text-light">📌 Customer Information</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <tr><th>Name</th><td>{{ $order->name ?? 'N/A' }}</td></tr>
                                    <tr><th>Email</th><td>{{ $order->email ?? 'N/A' }}</td></tr>
                                    <tr><th>Phone</th><td>{{ $order->phone_number ?? 'N/A' }}</td></tr>
                                    <tr><th>Emergency Phone</th><td>{{ $order->emergency_phone_number ?? 'N/A' }}</td></tr>
                                    <tr><th>Billing Address</th><td>{{ $order->billing_address ?? 'N/A' }}</td></tr>
                                    <tr><th>Shipping Address</th><td>{{ $order->shipping_address ?? 'N/A' }}</td></tr>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Order Summary -->
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">🛒 Order Summary</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <tr><th>Order ID</th><td>#{{ $order->order_id ?? 'N/A' }}</td></tr>
                                    <tr><th>Delivery Location</th>
                                        <td><span class="badge bg-info">{{ ucfirst($order->delivery_location ?? 'Unknown') }}</span></td>
                                    </tr>
                                    <tr><th>Payment Method</th>
                                        <td>
                                            @if(isset($order->payment_method))
                                                @php
                                                    $payment_methods = [1 => 'Cash on Delivery', 2 => 'Online Payment',];
                                                    $payment_badges = [1 => 'success', 2 => 'primary', 3 => 'warning'];
                                                @endphp
                                                <span class="badge bg-{{ $payment_badges[$order->payment_method] ?? 'secondary' }}">
                                                    {{ $payment_methods[$order->payment_method] ?? 'Other' }}
                                                </span>
                                            @else
                                                <span class="badge bg-secondary">N/A</span>
                                            @endif
                                        </td>
                                    </tr>
                                    <tr><th>Total Amount</th><td><strong>৳{{ number_format($order->total_amount ?? 0, 2) }}</strong></td></tr>
                                    <tr><th>Delivery Charge</th><td>৳{{ number_format($order->delivery_charge ?? 0, 2) }}</td></tr>
                                    <tr><th>Grant Total</th><td><strong>৳{{ number_format($order->total_amount + $order->delivery_charge  ?? 0, 2) }}</strong></td></tr>
                                    <tr><th>Status</th>
                                        <td>
                                            @php
                                                $statuses = [1 => 'Completed', 0 => 'Pending', 2 => 'Processing'];
                                                $status_badges = [1 => 'success', 0 => 'danger', 2 => 'warning'];
                                            @endphp
                                            <span class="badge bg-{{ $status_badges[$order->status] ?? 'secondary' }}">
                                                {{ $statuses[$order->status] ?? 'N/A' }}
                                            </span>
                                        </td>
                                    </tr>
                                    <tr><th>Transaction ID</th><td>{{ $order->trax_id ?? 'N/A' }}</td></tr>
                                    <tr><th>Order Placed At</th>
                                        <td>{{ isset($order->created_at) ? \Carbon\Carbon::parse($order->created_at)->format('d M Y, h:i A') : 'N/A' }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Ordered Products -->
                <div class="mt-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0 text-light">📦 Ordered Products</h5>
                        </div>
                        <div class="card-body">
                            @if(isset($order->orderProducts) && $order->orderProducts->count() > 0)
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Product Name</th>
                                            <th>Quantity</th>
                                            <th>Unit Price</th>
                                            <th>Total Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($order->orderProducts as $key => $product)
                                        <tr>
                                            <td>{{ $key + 1 }}</td>
                                            <td>
                                                <strong>{{ $product->product_name ?? '' }}</strong>
                                                <span class="quantity-badge"> {{ $product->quantity_name ?? '' }} </span>
                                            </td>

                                            <td>{{ $product->quantity ?? 0 }}</td>
                                            <td>৳{{ number_format($product->price ?? 0, 2) }}</td>
                                            <td>৳{{ number_format($product->total_price ?? 0, 2) }}</td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            @else
                                <p class="text-danger">No products found for this order.</p>
                            @endif
                        </div>
                    </div>
                </div>

            </div> <!-- End card-body -->
        @else
            <div class="alert alert-danger m-3">
                <strong>Error:</strong> Order data is not available.
            </div>
        @endif
    </div> <!-- End card -->
@endsection

@push('script')
    <script>
        // Additional JavaScript (if needed)
    </script>
@endpush
