<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class CartController extends Controller
{
    public function addToCart(Request $request)
    {
        // dd($request->all());
        $product_id = (int) $request->product_id;
        $quantity_id = $request->quantity_id ? (int) $request->quantity_id : null; // Nullable quantity selection
        $ip = $request->ip();
        $cart = Session::get('cart', []);

        $product = DB::table('products')->where('id', $product_id)->first();
        if (!$product) {
            return response()->json(['error' => 'Product not found'], 404);
        }

        // If a quantity is selected, fetch its details
        if (!empty($quantity_id)) {
            $productQuantity = DB::table('product_quantities')->where('id', $quantity_id)->first();
            if (!$productQuantity) {
                return response()->json(['error' => 'Invalid quantity selection'], 400);
            }
            $price = (float) $productQuantity->price;
            $quantity = 1;
        } else {
            $price = isset($product->discount_price) ? (float) $product->discount_price : (float) $product->price;
            $quantity = 1; // Default quantity
        }

        if (isset($cart[$product_id])) {
            $cart[$product_id]['quantity'] += 1;
        } else {
            $cart[$product_id] = [
                'id'            => (int) $product->id,
                'name'          => (string) $product->product_name,
                'price'         => $price,  // Ensuring float type
                'quantity'      => (int) $quantity,
                'quantity_id'   => $quantity_id,
                'quantity_name' => isset($productQuantity->quantity) ? (string) $productQuantity->quantity : '',
                'ip'            => (string) $ip,
            ];
        }

        Session::put('cart', $cart);
        return response()->json(['message' => 'Product added to cart', 'cart' => $cart]);
    }


    // View Cart
    public function viewCart()
    {
        Session::forget('buy_now');
        $cart = Session::get('cart', []);
        $cartWithDetails = [];

        foreach ($cart as $item) {
            $product = DB::table('products')->where('id', $item['id'])->first();
            if ($product) {
                $cartWithDetails[] = [
                    'product_id'    => $product->id,
                    'product_name'  => $product->product_name,
                    'price'         => (float) $item['price'],
                    'quantity'      => (int) $item['quantity'],
                    'image'         => $product->image ? Storage::url($product->image) : null,
                    'quantity_name' => $item['quantity_name'] ?? '',
                ];
            }
        }

        return response()->json(['cart' => $cartWithDetails]);
    }


    // Remove item from cart
    public function removeFromCart(Request $request)
    {
        $product_id = $request->product_id;
        $cart = Session::get('cart', []);

        if (isset($cart[$product_id])) {
            unset($cart[$product_id]);
            Session::put('cart', $cart);
        }

        return response()->json(['message' => 'Product removed from cart', 'cart' => $cart]);
    }

    // Clear Cart
    public function clearCart()
    {
        Session::forget('cart');
        return response()->json(['message' => 'Cart cleared']);
    }

    public function cartCount(){
        return response()->json([
            'cartCount' => count(session('cart', []))]);
    }

    public function updateCart(Request $request)
    {
        $product_id = $request->product_id;
        $action = $request->action;
        $cart = Session::get('cart', []);
        if (isset($cart[$product_id])) {
            if ($action == 'increase') {
                $cart[$product_id]['quantity'] += 1;
            }
            elseif ($action == 'decrease') {
                if ($cart[$product_id]['quantity'] > 1) {
                    $cart[$product_id]['quantity'] -= 1;
                }
            }
        } else {
            return response()->json(['error' => 'Product not found in cart'], 404);
        }

        Session::put('cart', $cart);

        // Calculate new total price for the product
        $updatedQuantity = $cart[$product_id]['quantity'];
        $updatedSubtotal = $cart[$product_id]['price'] * $updatedQuantity;

        return response()->json([
            'message' => 'Cart updated successfully',
            'cart' => $cart,
            'updatedQuantity' => $updatedQuantity,
            'updatedSubtotal' => number_format($updatedSubtotal, 2),
        ]);
    }

}
