<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'order_id',
        'user_ip',
        'name',
        'email',
        'phone_number',
        'billing_address',
        'shipping_address',
        'payment_method',
        'payment_method_name',
        'payment_account_number',
        'trax_id',
        'total_amount',
        'status',
        'delivery_charge',
        'delivery_location',
        'emergency_phone_number',
    ];
    public function orderProducts()
    {
        return $this->hasMany(OrderProduct::class);
    }

    public static function generateOrderNumber()
    {
        $todayDate = now()->format('Y-m-d');
        $lastOrder = self::whereDate('created_at', now())->latest('id')->first();
        $lastCounter = $lastOrder ? (int) substr($lastOrder->order_id, -4) : 0;
        $newCounter = str_pad($lastCounter + 1, 4, '0', STR_PAD_LEFT);
        return "{$todayDate}-{$newCounter}";
    }

    const ORDER_STATUSES = [
        0 => 'Pending',
        1 => 'Approved',
        2 => 'On the way',
        3 => 'Delivered',
        4 => 'Rejected',
    ];

    public function scopeFilters($query, $filters)
    {
        return $query->when(!empty($filters['search']), function ($q) use ($filters) {
            $q->where(function ($query) use ($filters) {
                $query->where('name', 'like', '%' . $filters['search'] . '%')
                    ->orWhere('email', 'like', '%' . $filters['search'] . '%')
                    ->orWhere('phone_number', 'like', '%' . $filters['search'] . '%')
                    ->orWhere('billing_address', 'like', '%' . $filters['search'] . '%')
                    ->orWhere('shipping_address', 'like', '%' . $filters['search'] . '%');
            });
        })
            ->when(isset($filters['status']), function ($q) use ($filters) {
                $q->where('status', $filters['status']);
            });
    }
}
