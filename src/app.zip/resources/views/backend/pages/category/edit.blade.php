@extends('backend.template.template')
@section('title', 'Edit Category')
@push('css')

@endpush
@section('main')

    <div class="row mb-2">
        <div class="col">
            <h4 class="py-3 mb-4 fs-5 d-inline">
                <span class="text-muted fw-light">Administration /</span>
                <span class="heading-color">Edit Category</span>
            </h4>
        </div>
        <div class="col text-end">
            <a href="{{ route('category.index') }}" class="btn btn-primary me-sm-3 me-1 waves-effect waves-light">
                <i class="ti ti-arrow-left me-sm-1 ti-xs"></i> All Categories
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-10 m-auto">
            <div class="card mb-4">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h5 class="mb-0">Edit Category</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('category.update', $category->id) }}" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="row g-3">
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="category-name">Category Name</label>
                                    <div class="col-sm-9">
                                        <input name="category_name" type="text" class="form-control @error('category_name') is-invalid @enderror"
                                               id="category-name" placeholder="Category Name" value="{{ old('category_name', $category->category_name) }}" />
                                        @error('category_name')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row mb-3">
                                    <label class="col-sm-3 col-form-label text-sm-end" for="status">Status</label>
                                    <div class="col-sm-9 d-inline-block">
                                        <div class="vs-radio-con me-3">
                                            <input type="radio" name="status" value="1" class="@error('status') is-invalid @enderror"
                                                {{ old('status', $category->status) == '1' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">Active</span>
                                        </div>
                                        <div class="vs-radio-con">
                                            <input type="radio" name="status" value="0" class="@error('status') is-invalid @enderror"
                                                {{ old('status', $category->status) == '0' ? 'checked' : '' }} />
                                            <span class="vs-radio">
                                                <span class="vs-radio--border"></span>
                                                <span class="vs-radio--circle"></span>
                                            </span>
                                            <span class="">Inactive</span>
                                        </div>
                                        @error('status')
                                        <p class="text-danger">{{ $message }}</p>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <div class="row justify-content-end">
                                    <div class="col-sm-12">
                                        <button type="submit" class="btn btn-primary me-sm-3 me-1 waves-effect waves-light">Update</button>
                                        <a href="{{ route('category.index') }}" class="btn btn-label-secondary waves-effect">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
@push('script')

@endpush
