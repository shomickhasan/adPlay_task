@extends('backend.template.template')
@section('title',  "Orders")
@push('css')
    <style>
        .dropdown-menu {
            display: none;
        }

        .show > .dropdown-menu {
            display: block;
        }
    </style>
@endpush
@section('main')
    <h4 class="py-3 mb-4 fs-5 ">
        <span class="text-muted fw-light">Adminstration/</span>
        <span class="heading-color">Orders</span>
    </h4>
    <div class="card">
        <div class="card-header">
            <div class="btn-group">
                <button  class="btn filter-btn btn-secondary add-new btn-primary waves-effect waves-light"><span> <i class="ti ti-filter me-0 me-sm-1 ti-xs"></i>&nbsp; Filter </span></button>
            </div>
        </div>
        <div class="card-body">
            <form class="dt_adv_search filter" method="get" action="{{ route('orders.index') }}" id="searchForm"  style="display: none">
                <div class="row">
                    <div class="col-12">
                        <div class="row g-3">
                            <div class="col-12 col-sm-6 col-lg-3">
                                <label class="form-label">Search</label>
                                <input type="text" name="search" class="form-control dt-input" data-column="3" placeholder="Search" data-column-index="2">
                            </div>
                            <div class="col-12 col-sm-6 col-lg-3">
                                <label class="form-label">Order Status:</label>
                                <select id="order_status" name="status" class="select2 form-select @error('status') is-invalid @enderror" data-allow-clear="true">
                                    <option value="">Select Status</option>
                                    @foreach (\App\Models\Order::ORDER_STATUSES as $key => $status)
                                        <option value="{{ $key }}" @if (old('status', '') == $key) selected @endif>{{ $status }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-12 col-sm-6 col-lg-3 d-flex align-items-end" style="justify-content: start;">
                                <div class="input-group-append me-2" id="button-addon2">
                                    <button id="search" class="btn btn-md btn-primary waves-effect waves-light index-search" type="button">
                                        <span><i class="ti ti-filter me-0 me-sm-1 ti-xs"></i>&nbsp; Filter</span>
                                    </button>
                                </div>
                                <div class="input-group-append" id="button-addon2">
                                    <button class="btn btn-md btn-danger waves-effect waves-light" onclick="resetForm()" type="reset">
                                        <span><i class="ti ti-square-x me-0 me-sm-1 ti-xs"></i>&nbsp; Clear</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </form>
        </div>
        <div id="filterTable">
            <div class="card-datatable table-responsive">
                <table class="datatables-products table item_table table-hover table-responsive">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Order ID</th>
                        <th>Customer Name</th>
                        <th>Phone Number</th>
                        <th>Total Amount</th>
                        <th>Payment Method</th>
                        <th>Delivery Location</th>
                        <th>Actions</th>
                        <th>Status</th> <!-- Moved Status Column -->
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($orders as $key => $order)
                        <tr>
                            <td>{{ $orders->firstItem() + $key }}</td>
                            <td>{{ $order->order_id }}</td>
                            <td>{{ $order->name }}</td>
                            <td>{{ $order->phone_number }}</td>
                            <td>৳{{ number_format($order->total_amount, 2) }}</td>
                            <td>
                                @if($order->payment_method == 1)
                                    Cash on Delivery
                                @else
                                    Online Payment
                                @endif
                            </td>
                            <td>{{ ucfirst($order->delivery_location) }}</td>
                            <td>
                                <a href="{{route('orders.details',$order->id)}}" class="btn btn-sm btn-info">View</a>
                            </td>
                            <td> <!-- Status Button Here -->
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm dropdown-toggle waves-effect waves-light"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        {{ \App\Models\Order::ORDER_STATUSES[$order->status] ?? 'Unknown' }}
                                    </button>
                                    <div class="dropdown-menu">
                                        @foreach(\App\Models\Order::ORDER_STATUSES as $statusKey => $statusLabel)
                                            @if($statusKey != $order->status)
                                                <a href="#" class="dropdown-item change-status"
                                                   data-order-id="{{ $order->id }}"
                                                   data-status="{{ $statusKey }}"
                                                   data-url="{{ route('orders.statusControl', $order->id) }}">
                                                    {{ $statusLabel }}
                                                </a>
                                            @endif
                                        @endforeach
                                    </div>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="9" class="text-center">No orders found.</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center mb-2">
              {{ $orders->links('backend.pagination.custome') }}
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script>
        $('#search').on('click', function() {
            var formData = $('#searchForm').serialize();
            $.ajax({
                type: 'GET',
                url: '{{route('orders.index')}}',
                data: formData,
                success: function(response) {
                    $('#filterTable').html(response);
                },
                error: function(error) {

                }
            });
        });

        $(document).ready(function () {
            $('.dropdown-toggle').dropdown();
            $(document).on("click", ".change-status", function (e) {
                e.preventDefault();

                let orderId = $(this).data("order-id");
                let status = $(this).data("status");
                let url = $(this).data("url");

                changeStatus(orderId, status, url);
            });

            function changeStatus(orderId, status, url) {
                Swal.fire({
                    title: "Are you sure?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: "Yes, change it!",
                    customClass: {
                        confirmButton: "btn btn-primary me-3 waves-effect waves-light",
                        cancelButton: "btn btn-label-secondary waves-effect waves-light",
                    },
                    buttonsStyling: false,
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "GET",
                            url: url,
                            data: {
                                id: orderId,
                                status: status
                            },
                            success: function(response) {
                                // Update dropdown text dynamically
                                let dropdownButton = $(`button[data-order-id="${orderId}"]`);
                                let dropdownMenu = dropdownButton.next(".dropdown-menu");
                                window.location.reload();
                                dropdownButton.text(response.new_status_label);
                                dropdownMenu.html("");
                                $.each(response.available_statuses, function(key, label) {
                                    if (key != status) {
                                        dropdownMenu.append(`
                                <a class="dropdown-item" href="#"
                                   onclick="changeStatus(${orderId}, ${key}, '${url}')">
                                    ${label}
                                </a>
                            `);
                                    }
                                });

                                // Show success message
                                Swal.fire({
                                    icon: "success",
                                    title: "Status Changed!",
                                    text: "The status has been successfully updated.",
                                    customClass: {
                                        confirmButton: "btn btn-success waves-effect waves-light",
                                    },
                                });
                            },
                            error: function() {
                                Swal.fire({
                                    icon: "error",
                                    title: "Error!",
                                    text: "There was an issue changing the status. Please try again.",
                                    customClass: {
                                        confirmButton: "btn btn-danger waves-effect waves-light",
                                    },
                                });
                            }
                        });
                    }
                });
            }

        });


    </script>

@endpush

