@extends('frontend.main')
@section('ftitle', 'Product Details')
@section('frontend')
@push('css')
    <style>
        .quantity-option {
            display: inline-block;
            margin-right: 10px;
            margin-bottom: 5px;
        }

        .quantity-option span {
            display: inline-block;
            padding: 10px 20px;
            border: 2px solid #164744; /* default red border */
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
            background-color: #f8f9fa;
            color: black;
            text-align: center;
            user-select: none;
        }

        /* When checked, change to green */
        .quantity-option input:checked + span {
            background-color: #164744; /* green */
            border-color: #164744;
            color: #fff;
        }

        /* Hover effect */
        .quantity-option:hover span {
            background-color: #e2e6ea;
        }

        /* Prevent zoom-in on mobile iOS (optional, but helpful for some users) */
        input[type="radio"] {
            transform: scale(1);
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
        }

        /* Fullscreen overlay */
        .custom-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5); /* dark background */
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1050; /* above other content */
        }

        /* Modal box */
        .custom-modal-content {
            background: #fff;
            padding: 20px 30px;
            border-radius: 10px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 0 15px rgba(0,0,0,0.3);
        }
        a.buy_now_btn.add-cart-btn.btn-warning {
            cursor: pointer;
            background-color: #164744;
            border-color: #164744;
        }

        .custom-btn-area {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-top: 10px;
        }

        /* Ensure that the buttons fill the available space properly */
        .pro-cart-btn {
            flex: 1;  /* Each button will take equal width */
        }

        /* Media query for smaller screens */
        @media (max-width: 768px) {
            .custom-btn-area {
                flex-direction: column; /* Stack the buttons vertically on small screens */
                align-items: center;  /* Center the buttons horizontally */
            }

            .pro-cart-btn {
                width: 100%; /* Make each button take full width on small screens */
                margin-bottom: 10px; /* Add some space between buttons */
            }

            /* Remove the flex properties to make sure buttons do not stretch on smaller screens */
            .custom-btn-area .add_cart_btn {
                width: auto;  /* Reset any width stretching */
            }
        }



        .custom-btn-area {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .pro-cart-btn {
            flex: 1;
            min-width: 150px;
        }

        .add-cart-btn {
            width: 100%;
            box-sizing: border-box;
        }



    </style>
@endpush
<!-- page title area start -->
{{--  <!--<section class="page__title p-relative d-flex align-items-center" data-background="">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-xl-12">-->
<!--                <div class="page__title-inner text-center">-->
<!--                    <h1>Product Details</h1>-->
<!--                    <div class="page__title-breadcrumb">-->
<!--                        <nav aria-label="breadcrumb">-->
<!--                        <ol class="breadcrumb justify-content-center">-->
<!--                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>-->
<!--                            <li class="breadcrumb-item active" aria-current="page"> Product details</li>-->
<!--                        </ol>-->
<!--                        </nav>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</section>-->  --}}
<!-- page title area end -->


<!-- shop details area start -->
<section class="shop__area pb-65">
    <div class="shop__top grey-bg-6 pt-100 pb-90">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <div class="product__modal-box d-flex">
                       {{-- <div class="product__modal-nav mr-20">
                            <nav>
                                <div class="nav nav-tabs" id="product-details" role="tablist">
                                    <a class="nav-item nav-link active" id="pro-one-tab" data-bs-toggle="tab" href="#pro-one" role="tab" aria-controls="pro-one" aria-selected="true">
                                    <div class="product__nav-img w-img">
                                        <img src="{{ Storage::url($product->image) }}" alt="">
                                    </div>
                                    </a>
                                    <a class="nav-item nav-link" id="pro-two-tab" data-bs-toggle="tab" href="#pro-two" role="tab" aria-controls="pro-two" aria-selected="false">
                                    <div class="product__nav-img w-img">
                                        <img src="{{ Storage::url($product->image) }}" alt="">
                                    </div>
                                    </a>
                                    <a class="nav-item nav-link" id="pro-three-tab" data-bs-toggle="tab" href="#pro-three" role="tab" aria-controls="pro-three" aria-selected="false">
                                    <div class="product__nav-img w-img">
                                        <img src="{{ Storage::url($product->image) }}" alt="">
                                    </div>
                                    </a>
                                </div>
                            </nav>
                        </div>--}}
                        <div class="tab-content mb-20" id="product-detailsContent">
                            <div class="tab-pane fade show active" id="pro-one" role="tabpanel" aria-labelledby="pro-one-tab">
                                <div class="product__modal-img product__thumb w-img">
                                    <img src="{{ Storage::url($product->image) }}" alt="">
                                    <div class="product__sale ">
                                        <span class="new">new</span>
                                        {{--<span class="percent">-16%</span>--}}
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pro-two" role="tabpanel" aria-labelledby="pro-two-tab">
                                <div class="product__modal-img product__thumb w-img">
                                    <img src="{{ Storage::url($product->image) }}" alt="">
                                    <div class="product__sale ">
                                        <span class="new">new</span>
                                       {{-- <span class="percent">-16%</span>--}}
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pro-three" role="tabpanel" aria-labelledby="pro-three-tab">
                                <div class="product__modal-img product__thumb w-img">
                                    <img src="{{asset('/')}}frontend/assets/img/shop/product/details/details-big-3.jpg" alt="">
                                    <div class="product__sale ">
                                        <span class="new">new</span>
                                       {{-- <span class="percent">-16%</span>--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="product__modal-content product__modal-content-2">
                        <h4><a href="#">{{$product->product_name ?? ''}}</a></h4>
                       {{-- <div class="rating rating-shop mb-15">
                            <ul>
                                <li><span><i class="fas fa-star"></i></span></li>
                                <li><span><i class="fas fa-star"></i></span></li>
                                <li><span><i class="fas fa-star"></i></span></li>
                                <li><span><i class="fas fa-star"></i></span></li>
                                <li><span><i class="fal fa-star"></i></span></li>
                            </ul>
                            <span class="rating-no ml-10 rating-left">
                                3 rating(s)
                            </span>
                            <span class="review rating-left"><a href="#">Add your Review</a></span>
                        </div>--}}
                        <div class="product__price-2 mb-25">
                            <span id="product-price">৳ {{ isset($product->discount_price) ? $product->discount_price : $product->price }}</span>
                            <span id="old-price" class="old-price">{{ isset($product->discount_price) ? $product->price : '' }}</span>
                        </div>

                        <div class="product__modal-des mb-30">
                            {!! $product?->short_description ?? '' !!}
                        </div>

                        <div class="product__modal-form mb-30">
                            @if ($product->productQuantitys->isNotEmpty())
                                <div class="product-quantity-options mb-2 d-flex flex-wrap">
                                    @foreach ($product->productQuantitys as $quantity)
                                        <label class="quantity-option me-2">
                                            <input type="radio" name="quantity" value="{{ $quantity->id }}" class="d-none"
                                                   data-price="{{ $quantity->discount_price ?? $quantity->price }}"
                                                   data-old-price="{{ $quantity->discount_price ? $quantity->price : '' }}">
                                            <span>{{ $quantity->quantity }}</span>
                                        </label>
                                    @endforeach
                                </div>
                            @endif

                                <form action="#">
                                    <div class="pro-quan-area d-sm-flex align-items-center custom-btn-area">
                                        <div class="pro-cart-btn">
                                            <a class="add_to_cart add_to_cart_details add-cart-btn mr-10" data-product-id="{{ $product->id }}">+ Add to Cart</a>
                                        </div>
                                        <div class="pro-cart-btn">
                                            <a class="buy_now_btn add-cart-btn btn-warning" data-product-id="{{ $product->id }}">+ Buy Now</a>
                                        </div>
                                    </div>
                                </form>

                        </div>
                        <div class="product__tag mb-25">
                            <span>Category:</span>
                            <span><a href="#">{{$product?->category?->category_name ?? ''}}</a></span>
                        </div>
                       {{-- <div class="product__share">
                            <span>Share :</span>
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-behance"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                            </ul>
                        </div>--}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="shop__bottom">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="product__details-tab">
                        <div class="product__details-tab-nav text-center mb-45">
                            <nav>
                                <div class="nav nav-tabs justify-content-start justify-content-sm-center" id="pro-details" role="tablist">
                                    <a class="nav-item nav-link active" id="des-tab" data-bs-toggle="tab" href="#des" role="tab" aria-controls="des" aria-selected="true">Description</a>
                                    <a class="nav-item nav-link" id="add-tab" data-bs-toggle="tab" href="#add" role="tab" aria-controls="add" aria-selected="false">Shipping Information</a>
                                   {{-- <a class="nav-item nav-link" id="review-tab" data-bs-toggle="tab" href="#review" role="tab" aria-controls="review" aria-selected="false">Reviews (4)</a>--}}
                                </div>
                            </nav>
                        </div>
                        <div class="tab-content" id="pro-detailsContent">
                            <div class="tab-pane fade show active" id="des" role="tabpanel">
                                <div class="product__details-des">
                                    {!! $product->long_description ?? '' !!}
                                </div>
                            </div>
                            <div class="tab-pane fade" id="add" role="tabpanel">
                                <div class="product__details-add">
                                    {!! $product->shipping_info ?? '' !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- shop details area end -->

<!-- related products area start -->
<section class="related__product pb-60">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="section__title-wrapper text-center mb-55">
                    <div class="section__title mb-10">
                        <h2>Related Products</h2>
                    </div>
                    <div class="section__sub-title">
                        <p>Mirum est notare quam littera gothica quam nunc putamus parum claram!</p>
                    </div>
                </div>
            </div>
        </div>
        @if($trendings->isNotEmpty())
            <div class="row">
                @foreach ($trendings as $trending)
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 custom-col-10">
                        <div class="product__wrapper mb-60">
                            <div class="product__thumb">
                                <a href="{{route('fproductDetails',$trending->slug)}}" class="w-img">
                                    <img src="{{ Storage::url($trending->image) }}" alt="product-img">
                                    <img class="product__thumb-2" src="{{ Storage::url($trending->image) }}" alt="product-img">
                                </a>
                               {{-- <div class="product__action transition-3">
                                    <a href="#" data-bs-toggle="tooltip" data-placement="top" title="Add to Wishlist">
                                        <i class="fal fa-heart"></i>
                                    </a>
                                    <a href="#" data-bs-toggle="tooltip" data-placement="top" title="Compare">
                                        <i class="fal fa-sliders-h"></i>
                                    </a>
                                    <!-- Button trigger modal -->
                                    --}}{{--<a href="#" data-bs-toggle="modal" data-bs-target="#productModalId">
                                        <i class="fal fa-search"></i>
                                    </a>--}}{{--

                                </div>--}}
                                <div class="product__sale">
                                   {{-- <span class="new">new</span>--}}
                                    {{--<span class="percent">-16%</span>--}}
                                </div>
                            </div>
                            <div class="product__content p-relative">
                                <div class="product__content-inner">
                                    <h4><a href="{{route('fproductDetails',$trending->slug)}}">{{$trending->product_name ?? ''}}</a></h4>
                                    <div class="">
                                        <span>৳ {{isset($trending->discount_price) ? $trending->discount_price : $trending->price  }}</span>
                                        <span class="old-price">{{isset($trending->discount_price) ? $trending->price : '' }}</span>

                                    </div>
                                </div>
                                <div class="text-center">
                                    @if($trending->productQuantitys->isEmpty())
                                        <a href="javascript:void(0)" class="btn btn-dark add_to_cart mb-2"
                                           data-product-id="{{ $trending->id }}">
                                            + Add to Cart
                                        </a><br>

                                        <a style="background:#164744; width:100%" href="javascript:void(0)" class="btn btn-success buy_now_btn  mb-2"
                                           data-product-id="{{ $trending->id }}"
                                           data-quantity="1">
                                            Buy Now
                                        </a>
                                    @else
                                        <a style="width:100%" href="{{ route('fproductDetails', $trending->slug) }}" class="btn btn-dark mb-2 view_option">
                                            Select options
                                        </a><br>

                                        {{-- Assuming the first quantity ID is fine for "Buy Now" shortcut --}}
                                        <a style="width:100%" href="javascript:void(0)" class="btn btn-dark buy_now_btn mb-2"
                                           data-product-id="{{ $trending->id }}"
                                           data-quantity-id="{{ $trending->productQuantitys->first()->id ?? '' }}"
                                           data-quantity="1">
                                            Buy Now
                                        </a>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
                    <div class="row mt-40">
                        <div class="col-xl-12">
                            <div class="shop-pagination-wrapper d-md-flex justify-content-between align-items-center">
                                {{ $trendings->links('frontend.pagination.custom') }}
                            </div>
                        </div>
                    </div>
            </div>
        @else
            <p>No products found.</p>
        @endif
    </div>
</section>
<!-- related products area end -->

<!-- shop modal start -->
<!-- Modal -->
<div class="modal fade" id="productModalId" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered product-modal" role="document">
        <div class="modal-content">
            <div class="product__modal-wrapper p-relative">
                <div class="product__modal-close p-absolute">
                    <button   data-dismiss="modal"><i class="fal fa-times"></i></button>
                </div>
                <div class="product__modal-inner">
                    <div class="row">
                        <div class="col-xl-5 col-lg-5 col-md-6 col-sm-12 col-12">
                            <div class="product__modal-box">
                                <div class="tab-content mb-20" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                        <div class="product__modal-img w-img">
                                            <img src="{{asset('/')}}frontend/assets/img/shop/product/quick-view/quick-big-1.jpg" alt="">
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                        <div class="product__modal-img w-img">
                                            <img src="{{asset('/')}}frontend/assets/img/shop/product/quick-view/quick-big-2.jpg" alt="">
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                                        <div class="product__modal-img w-img">
                                            <img src="{{asset('/')}}frontend/assets/img/shop/product/quick-view/quick-big-3.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <nav>
                                    <div class="nav nav-tabs justify-content-between" id="nav-tab" role="tablist">
                                        <a class="nav-item nav-link active" id="nav-home-tab" data-bs-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">
                                        <div class="product__nav-img w-img">
                                            <img src="{{asset('/')}}frontend/assets/img/shop/product/quick-view/quick-sm-1.jpg" alt="">
                                        </div>
                                        </a>
                                        <a class="nav-item nav-link" id="nav-profile-tab" data-bs-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">
                                        <div class="product__nav-img w-img">
                                            <img src="{{asset('/')}}frontend/assets/img/shop/product/quick-view/quick-sm-2.jpg" alt="">
                                        </div>
                                        </a>
                                        <a class="nav-item nav-link" id="nav-contact-tab" data-bs-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">
                                        <div class="product__nav-img w-img">
                                            <img src="{{asset('/')}}frontend/assets/img/shop/product/quick-view/quick-sm-3.jpg" alt="">
                                        </div>
                                        </a>
                                    </div>
                                    </nav>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7 col-md-6 col-sm-12 col-12">
                            <div class="product__modal-content">
                                <h4><a href="product-details.html">Wooden container Bowl</a></h4>
                                <div class="rating rating-shop mb-15">
                                    <ul>
                                        <li><span><i class="fas fa-star"></i></span></li>
                                        <li><span><i class="fas fa-star"></i></span></li>
                                        <li><span><i class="fas fa-star"></i></span></li>
                                        <li><span><i class="fas fa-star"></i></span></li>
                                        <li><span><i class="fal fa-star"></i></span></li>
                                    </ul>
                                    <span class="rating-no ml-10">
                                        3 rating(s)
                                    </span>
                                </div>
                                <div class="product__price-2 mb-25">
                                    <span>$96.00</span>
                                    <span class="old-price">$96.00</span>
                                </div>
                                <div class="product__modal-des mb-30">
                                    <p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram.</p>
                                </div>
                                <div class="product__modal-form">
                                    <form action="#">
                                        <div class="product__modal-input size mb-20">
                                            <label>Size <i class="fas fa-star-of-life"></i></label>
                                            <select>
                                                <option>- Please select -</option>
                                                <option> S</option>
                                                <option> M</option>
                                                <option> L</option>
                                                <option> XL</option>
                                                <option> XXL</option>
                                            </select>
                                        </div>
                                        <div class="product__modal-input color mb-20">
                                            <label>Color <i class="fas fa-star-of-life"></i></label>
                                            <select>
                                                <option>- Please select -</option>
                                                <option> Black</option>
                                                <option> Yellow</option>
                                                <option> Blue</option>
                                                <option> White</option>
                                                <option> Ocean Blue</option>
                                            </select>
                                        </div>
                                        <div class="product__modal-required mb-5">
                                            <span >Repuired Fiields *</span>
                                        </div>
                                        <div class="pro-quan-area d-lg-flex align-items-center">
                                            <div class="product-quantity-title">
                                                <label>Quantity</label>
                                            </div>
                                            <div class="product-quantity">
                                                <div class="cart-plus-minus"><input type="text" value="1" /></div>
                                            </div>
                                            <div class="pro-cart-btn ml-20">
                                                <a href="#" class="add-cart-btn mr-10">+ Add to Cart</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Buy Now Modal -->
<div class="modal fade" id="buyNowModal" tabindex="-1" role="dialog" aria-labelledby="buyNowModalLabel" aria-hidden="true"  tabindex="-1"
     role="dialog"
     aria-labelledby="buyNowModalLabel"
     aria-hidden="true"
     data-backdrop="static"
     data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered" role="document"> <!-- Centered vertically -->
        <div class="modal-content">
            <form id="buyNowForm">
                <div class="modal-header">
                    <h5 class="modal-title" id="buyNowModalLabel">Enter Quantity</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <input type="hidden" id="modalProductId">
                    <input type="hidden" id="modalQuantityId">
                    <input type="number" id="modalQuantity" min="1" value="1" class="form-control" placeholder="Enter quantity" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="modalBuyNowBtn" class="btn btn-warning text-light" disabled>Confirm Quantity</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection
@push('script')
    <script>
        $(document).ready(function() {
            $(document).on("click", ".add_to_cart_details", function (e) {
                e.preventDefault();
                let productId = $(this).data("product-id");
                let quantityInput = $("input[name='quantity']");
                if (quantityInput.length > 0) {
                    let selectedQuantity = quantityInput.filter(":checked").val();

                    if (!selectedQuantity) {
                        showToast('error', 'Please select a quantity before adding to cart', '');
                        return;
                    }

                    addToCartDetails(productId, selectedQuantity);
                } else {
                    // If no quantity selection exists, proceed without a quantity ID
                    addToCartDetails(productId, null);
                }
            });


            let buyNowUrl = "{{ route('buy.now') }}";

// Show modal with product info
            $(document).on("click", ".buy_now_btn", function (e) {
                e.preventDefault();

                let productId = $(this).data("product-id");
                let quantityInput = $("input[name='quantity']");
                let quantityId = null;

                if (quantityInput.length > 0) {
                    let selected = quantityInput.filter(":checked").val();
                    if (!selected) {
                        showToast('error', 'Please select a quantity option first', '');
                        return;
                    }
                    quantityId = selected;
                }

                $("#modalProductId").val(productId);
                $("#modalQuantityId").val(quantityId);
                $("#modalQuantity").val(1);
                $("#modalBuyNowBtn").prop("disabled", false); // default value is valid

                $("#buyNowModal").modal("show");
            });

// Enable/Disable Buy Now button based on quantity input
            $("#modalQuantity").on("input", function () {
                let qty = parseInt($(this).val());
                if (!qty || qty < 1) {
                    $("#modalBuyNowBtn").prop("disabled", true);
                } else {
                    $("#modalBuyNowBtn").prop("disabled", false);
                }
            });

// Handle Buy Now form submit
            $("#buyNowForm").on("submit", function (e) {
                e.preventDefault();

                const productId = $("#modalProductId").val();
                const quantityId = $("#modalQuantityId").val() || null;
                const quantity = parseInt($("#modalQuantity").val());
                const csrfToken = $('meta[name="csrf-token"]').attr('content');

                if (!quantity || quantity < 1) {
                    showToast('error', 'Please enter a valid quantity.', '');
                    return;
                }

                $.ajax({
                    url: buyNowUrl,
                    method: 'POST',
                    data: {
                        product_id: productId,
                        quantity_id: quantityId,
                        quantity: quantity,
                        _token: csrfToken
                    },
                    success: function (response) {
                        $("#buyNowModal").modal("hide");
                        window.location.href = '{{ route("fcheckout") }}?buy_now=1';
                    },
                    error: function (xhr) {
                        const errorMsg = xhr.responseJSON?.error || 'Something went wrong';
                        showToast('error', errorMsg, '');
                    }
                });
            });


            $(document).on("click", ".modal .close", function () {
                $("#buyNowModal").modal("hide");
            });

            $('#buyNowModal').modal({
                backdrop: 'static',
                keyboard: false
            });


            $(document).on("change", "input[name='quantity']", function () {
                let selectedPrice = $(this).data("price");
                let selectedOldPrice = $(this).data("old-price") || '';

                $("#product-price").text('৳ ' + selectedPrice);
                $("#old-price").text(selectedOldPrice ? '৳ ' + selectedOldPrice : '');
            });

            function addToCartDetails(productId, quantityId) {
                $.ajax({
                    url: '/add-to-cart',
                    method: 'POST',
                    data: {
                        product_id: productId,
                        quantity_id: quantityId || null,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function (response) {
                        showToast('success', 'Product added to cart!', '');
                        cartCount(response.cart);
                    },
                    error: function (xhr) {
                        showToast('error', xhr.responseJSON?.error || 'Something went wrong', '');
                    }
                });
            }





        });
    </script>
@endpush
