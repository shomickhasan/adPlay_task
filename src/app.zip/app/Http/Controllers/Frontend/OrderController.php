<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\OrderRequest;
use App\Models\Order;
use App\Models\OrderProduct;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    public function store(OrderRequest $request)
    {
        // Check if both cart and buy_now sessions are empty
        if (
            (empty(session('cart')) || !session()->has('cart')) &&
            empty(session('buy_now'))
        ) {
            return redirect()->back()->with('error', 'Your cart is empty.');
        }

        try {
            DB::beginTransaction();

            // Use buy_now data if available, otherwise use cart
            $cartData = session('buy_now') ?: session('cart');

            $totalAmount = collect($cartData)->sum(function ($item) {
                return $item['quantity'] * $item['price'];
            });

            $deliveryCharge = $request->delivery_location === 'inside dhaka' ? 80 : 100;

            $order = Order::create([
                'user_id' => auth()->id(),
                'order_id' => Order::generateOrderNumber(),
                'user_ip' => request()->ip(),
                'name' => $request->name,
                'email' => $request->email,
                'phone_number' => $request->phone_number,
                'billing_address' => $request->billing_address,
                'shipping_address' => $request->shipping_address,
                'payment_method' => $request->payment_method,
                'payment_method_name' => $request->payment_method_name,
                'payment_account_number' => $request->payment_account_number,
                'trax_id' => $request->trax_id,
                'total_amount' => $totalAmount,
                'status' => 0,
                'delivery_charge' => $deliveryCharge,
                'delivery_location' => $request->delivery_location,
                'emergency_phone_number' => $request->emergency_phone_number,
            ]);

            foreach ($cartData as $product_id => $details) {
                OrderProduct::create([
                    'order_id' => $order->id,
                    'product_id' => $product_id,
                    'product_name' => $details['name'],
                    'quantity' => $details['quantity'],
                    'price' => $details['price'],
                    'quantity_name' => $details['quantity_name'] ?? null,
                    'total_price' => $details['quantity'] * $details['price'],
                ]);
            }

            // Forget the relevant session data
            if (!empty(session('buy_now'))) {
                Session::forget('buy_now');
            } else {
                Session::forget('cart');
            }

            DB::commit();

            return redirect()->route('home')->with('message', 'Your order has been placed successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Order store error: ' . $e->getMessage());
            return redirect()->route('home')->with('error', 'Something went wrong. Please try again.');
        }
    }



}
