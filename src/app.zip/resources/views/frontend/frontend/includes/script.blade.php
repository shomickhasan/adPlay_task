<script src="{{asset('/')}}frontend/assets/js/vendor/jquery.js"></script>
<script src="{{asset('/')}}frontend/assets/js/bootstrap.js"></script>
<script src="{{asset('/')}}frontend/assets/js/metisMenu.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/slick.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/jquery.fancybox.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/isotope.pkgd.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/owl.carousel.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/jquery-ui-slider-range.js"></script>
<script src="{{asset('/')}}frontend/assets/js/ajax-form.js"></script>
<script src="{{asset('/')}}frontend/assets/js/wow.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/imagesloaded.pkgd.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/main.js"></script>
<script src="{{asset('/')}}frontend/assets/js/custom.js"></script>
<!-- Toastr -->
<script src="{{asset('/')}}app-assets/vendor/libs/toastr/toastr.js"></script>

<script>
    //toster initilaxitions
    @if(Session::has('message'))
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.success("{{ session('message') }}");
    @endif

        @if(Session::has('error'))
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.error("{{ session('error') }}");
    @endif

        @if(Session::has('info'))
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.info("{{ session('info') }}");
    @endif

        @if(Session::has('warning'))
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.warning("{{ session('warning') }}");
    @endif
</script>

@stack('script')
