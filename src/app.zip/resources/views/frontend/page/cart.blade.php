@extends('frontend.main')
@section('ftitle', 'Cart')
@section('frontend')

<!-- page title area start -->
{{--  <!--<section class="page__title p-relative d-flex align-items-center" data-background="{{asset('/')}}frontend/assets/img/page-title/page-title-1.jpg">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-xl-12">-->
<!--                <div class="page__title-inner text-center">-->
<!--                    <h1>Your Cart</h1>-->
<!--                    <div class="page__title-breadcrumb">-->
<!--                        <nav aria-label="breadcrumb">-->
<!--                        <ol class="breadcrumb justify-content-center">-->
<!--                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>-->
<!--                            <li class="breadcrumb-item active" aria-current="page"> Cart</li>-->
<!--                        </ol>-->
<!--                        </nav>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</section>-->  --}}
<!-- page title area end -->

<!-- Cart Area Strat-->
<section class="cart-area pt-100 pb-100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <form action="#">
                    <div class="table-content table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="product-thumbnail">Images</th>
                                    <th class="cart-product-name">Product</th>
                                    <th class="product-price">Unit Price</th>
                                    <th class="product-quantity">Quantity</th>
                                    <th class="product-subtotal">Total</th>
                                    <th class="product-remove">Remove</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                  {{--  <div class="row">
                        <div class="col-12">
                            <div class="coupon-all">
                                <div class="coupon">
                                    <input id="coupon_code" class="input-text" name="coupon_code" value=""
                                        placeholder="Coupon code" type="text">
                                    <button class="os-btn os-btn-black" name="apply_coupon" type="submit">Apply
                                        coupon</button>
                                </div>
                                <div class="coupon2">
                                    <button class="os-btn os-btn-black" name="update_cart" type="submit">Update cart</button>
                                </div>
                            </div>
                        </div>
                    </div>--}}
                    <div class="row">
                        <div class="col-md-5 ml-auto">
                            <div class="cart-page-total">
                                <h2>Cart Totals</h2>
                                <ul class="mb-20">
                                    <li>Subtotal <span class="cart-subtotal">৳ 0.00</span></li>
                                    <li>Total <span class="cart-total">৳ 0.00</span></li>
                                </ul>
                                <a class="os-btn" href="{{route('fcheckout')}}">Proceed to Checkout</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- Cart Area End-->


@endsection

@push('script')
    <script>
        $(document).ready(function () {
            fetchCartData();
        });
        function fetchCartData() {
            $.ajax({
                url: "/view-cart",
                method: "GET",
                success: function (response) {
                    let cartHtml = "";

                    if (response.cart.length === 0) {
                        cartHtml = '<tr><td colspan="6" class="text-center">Your cart is empty.</td></tr>';
                    } else {
                        response.cart.forEach((item) => {
                            cartHtml += `
                    <tr data-product-id="${item.product_id}">
                        <td class="product-thumbnail">
                            <img src="${item.image}" alt="${item.product_name}" class="img-fluid" width="50">
                        </td>
                        <td class="product-name">${item.product_name} ${item.quantity_name ? `<mark>(${item.quantity_name})</mark>` : ''}</td>
                        <td class="product-price"><span class="amount">৳ ${item.price.toFixed(2)}</span></td>
                        <td class="product-quantity">
                            <div class="input-group input-group-sm">
                                <button type="button" class="btn btn-outline-secondary btn-sm minus" data-product-id="${item.product_id}">−</button>
                                <span class="form-control text-center bg-light quantity" data-product-id="${item.product_id}">${item.quantity}</span>
                                <button type="button" class="btn btn-outline-secondary btn-sm plus" data-product-id="${item.product_id}">+</button>
                            </div>
                        </td>
                        <td class="product-subtotal"><span class="amount">৳ ${(item.price * item.quantity).toFixed(2)}</span></td>
                        <td class="product-remove">
                            <a href="#" data-product-id="${item.product_id}" class="btn btn-danger btn-sm remove-item">
                                <i class="fa fa-times"></i>
                            </a>
                        </td>
                    </tr>`;
                        });
                    }

                    $(".table-content tbody").html(cartHtml);
                    updateTotalCartPrice();
                },
                error: function () {
                    alert("Error loading cart.");
                },
            });
        }

        $(document).on("click", ".plus, .minus", function () {
            let productId = $(this).data("product-id");
            let action = $(this).hasClass("plus") ? "increase" : "decrease";
            let $productRow = $('tr[data-product-id="' + productId + '"]');
            let price = parseFloat($productRow.find(".product-price .amount").text().replace("৳", "").trim());

            $.ajax({
                url: "/update-cart-product-quantity",
                method: "POST",
                data: {
                    product_id: productId,
                    action: action,
                    _token: $('meta[name="csrf-token"]').attr("content"),
                },
                success: function (response) {
                    $productRow.find(".quantity").text(response.updatedQuantity);
                    let updatedSubtotal = (response.updatedQuantity * price).toFixed(2);
                    $productRow.find(".product-subtotal .amount").text("৳ " + updatedSubtotal);
                    updateTotalCartPrice();
                },
                error: function (xhr) {
                    alert("Error updating cart.");
                },
            });
        });

        $(document).on("click", ".remove-item", function (e) {
            e.preventDefault();

            let productId = $(this).data("product-id");
            let $productRow = $(this).closest("tr");

            $.ajax({
                url: "/remove-from-cart",
                method: "POST",
                data: {
                    product_id: productId,
                    _token: $('meta[name="csrf-token"]').attr("content"),
                },
                success: function (response) {
                    $productRow.remove();
                    showToast('success', 'Product Remove Form cart', '');
                    if ($(".table-content tbody tr").length === 0) {
                        $(".table-content tbody").html('<tr><td colspan="6" class="text-center">Your cart is empty.</td></tr>');
                    }
                    updateTotalCartPrice();
                },
                error: function () {
                    alert("Error removing product from cart.");
                },
            });
        });


        function updateTotalCartPrice() {
            let subtotal = 0;
            $(".product-subtotal .amount").each(function () {
                let itemSubtotal = parseFloat($(this).text().replace("৳", "").trim());
                subtotal += itemSubtotal;
            });
            let total = subtotal;
            $(".cart-page-total li:nth-child(1) span").text("৳ " + subtotal.toFixed(2));
            $(".cart-page-total li:nth-child(2) span").text("৳ " + total.toFixed(2));
        }




    </script>
@endpush
