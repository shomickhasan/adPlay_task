<?php

namespace App\Http\Controllers\Backend;

use App\Models\Product;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\ProductQuantity;
use App\Models\Backend\Category;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Requests\ProductAddRequest;
use App\Http\Requests\ProductStoreRequest;

class ProductController extends Controller
{


    public function index(Request $request)
    {
        $categories = Category::status(1)->orderByDescId()->get();
        $filters = $request->only(['created_at', 'product_name', 'status', 'ordering', 'category_id']);
        $sortOrder = $request->ordering ?? 'desc';
        $products = Product::filters($filters)->with('category')
            ->OrderByDescId()
            ->paginate(self::WEB_PAGINATOR_NUMBER)
            ->withQueryString();


        return $request->ajax()
            ? view('backend.pages.product.filter', compact('products','categories'))
            : view('backend.pages.product.index', compact('products','categories'));
    }
    public function create(Request $request){
        $categories = Category::status(1)->orderByDescId()->get();
        return view('backend.pages.product.create',compact('categories'));
    }
    public function store(ProductAddRequest $request)
    {
        $validated = $request->validated();


        try {
            $imagePath = $this->UploadImage($request, 'image', 'images/products');

            $product = Product::create([
                'cat_id' => $request->cat_id,
                'product_name' => $request->product_name,
                'slug' => Str::slug($request->product_name),
                'price' => $request->price,
                'discount_price' => $request->discount_price,
                'short_description' => $request->short_description,
                'long_description' => $request->long_description,
                'shipping_info' => $request->shipping_info,
                'image' => $imagePath,
                'stoke_status' => $request->stoke_status,
                'status' => $request->status,
                'is_feater_product' => $request->is_feater_product,
                'is_trending_product' => $request->is_trending_product,
                'is_show_home' => $request->is_show_home,
            ]);

            if ($request->quantities) {
                foreach ($request->quantities as $key => $quantity) {
                    if (!empty($quantity) && !empty($request->prices[$key])) {
                        ProductQuantity::create([
                            'product_id' => $product->id,
                            'quantity' => $quantity,
                            'price' => $request->prices[$key],
                        ]);
                    }
                }
            }

            return response()->json(['success' => true, 'message' => 'Product created successfully!']);

        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'There was an error creating the product.', 'error' => $e->getMessage()], 500);
        }
    }

    public function edit($id)
    {
        $product = Product::findOrFail($id);
        $categories = Category::all();
        return view('backend.pages.product.edit', compact('product', 'categories'));
    }
    public function update(ProductAddRequest $request, $id)
    {
        try {
            // Find the product by its ID
            $product = Product::findOrFail($id);
    
            // Handle image upload
            if ($request->hasFile('image')) {
                $this->deleteExistingImage($product->image);
                $imagePath = $this->UploadImage($request, 'image', 'images/products');
            } else {
                $imagePath = $product->image;
            }
    
            // Update main product details
            $product->update([
                'cat_id' => $request->cat_id,
                'product_name' => $request->product_name,
                'price' => $request->price,
                'discount_price' => $request->discount_price,
                'short_description' => $request->short_description,
                'long_description' => $request->long_description,
                'shipping_info' => $request->shipping_info,
                'image' => $imagePath,
                'stoke_status' => $request->stoke_status,
                'status' => $request->status,
                'is_feater_product' => $request->is_feater_product,
                'is_trending_product' => $request->is_trending_product,
                'is_show_home' => $request->is_show_home,
            ]);
    
            // Handle product quantities
            if ($request->has('quantities') && $request->has('prices')) {
                foreach ($request->quantities as $index => $quantity) {
                    $price = $request->prices[$index] ?? null;
                    $quantityId = $request->qunatity_id[$index] ?? null;
            

                    if ($quantityId) {
                    
                        $existingQuantity = $product->productQuantitys()->find($quantityId);
                        if ($existingQuantity) {
                            $existingQuantity->update([
                                'quantity' => $quantity,
                                'price' => $price,
                            ]);
                        }
                    } else {
                        // Create new quantity record
                        Log::info("shakil");
                        $product->productQuantitys()->create([
                            'quantity' => $quantity,
                            'price' => $price,
                        ]);
                    }
                }
            }
    
            return response()->json(['success' => 'Product updated successfully!']);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
    
    


    public function deleteQuantity($quantityId)
    {
        // Find the quantity record by ID
        $quantity = ProductQuantity::find($quantityId);

        // Check if the record exists
        if ($quantity) {
            // Delete the quantity record
            $quantity->delete();

            // Return a success response
            return response()->json(['success' => true, 'message' => 'Quantity deleted successfully']);
        }

        // Return error response if the quantity record is not found
        return response()->json(['success' => false, 'message' => 'Quantity not found'], 404);
    }

    public function destroy($id)
    {
        $product = Product::findOrFail($id);

        if ($product->image) {
            {
                $this->deleteExistingImage($product->image);
            }
        }
        $data = $product->delete();
        return response()->json([
            'data'=>$data,
            'success' => 'Product deleted successfully!'
        ]);

    }

    public function toggleStatus($id)
{
    $quantity = ProductQuantity::find($id);

    if (!$quantity) {
        return response()->json(['success' => false, 'message' => 'Quantity not found'], 404);
    }

    if($quantity->status == 1)
    {
        $quantity->status = 0;
        $quantity->save();
    }else{
        $quantity->status = 1;
        $quantity->save();
    }
 

    return response()->json([
        'success' => true,
        'message' => 'Quantity status updated successfully.',
        'status' => $quantity->status
    ]);
}

}
