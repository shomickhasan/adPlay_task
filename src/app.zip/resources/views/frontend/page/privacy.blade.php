@extends('frontend.main')
@section('ftitle', 'Privacy Policy')
@section('frontend')

<!-- page title area start -->
{{--  <!--<section class="page__title p-relative d-flex align-items-center" data-background="{{asset('/')}}frontend/assets/img/page-title/page-title-2.jpg">-->
<!--    <div class="container">-->
<!--        <div class="row">-->
<!--            <div class="col-xl-12">-->
<!--                <div class="page__title-inner text-center">-->
<!--                    <h1>Privacy Policy</h1>-->
<!--                    <div class="page__title-breadcrumb">                                 -->
<!--                        <nav aria-label="breadcrumb">-->
<!--                        <ol class="breadcrumb justify-content-center">-->
<!--                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>-->
<!--                            <li class="breadcrumb-item active" aria-current="page"> Privacy Policy</li>-->
<!--                        </ol>-->
<!--                        </nav>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</section>-->  --}}
<!-- page title area end -->

<!-- error area start -->
<section class="error__area pt-60 pb-100">
    <div class="container">
        <div class="col-xl-8 offset-xl-2 col-lg-8 offset-lg-2">
            <div class=" text-left">
                <h2>Privacy Policy</h2>
                <p>
                    Krishibid Bazaar Limited, owner of the www.krishibidbazaar.com is an Innovative
                     online based organic product and grocery shopping space and the website respects your privacy.
                      This Privacy Policy provides concisely the manner your data is collected and used by system on 
                      the Site. As a visitor to the Site/ Customer you are advised to please read the Privacy Policy 
                      carefully. By accessing 
                    the services provided by the Site you agree to the collection and use of your data by system.
                </p>
                <p>
                    As part of the registration process on the Site, system may
                     collect the following personally identifiable information about you: 
                     Name including first and last name, alternate email address, mobile phone number
                      and contact details, Postal code, Demographic profile (like your age, gender, occupation,
                       education, address etc.) and information about the pages on the site you visit/access,
                        the links you click on the site, the number of times you access the page and any such
                         browsing information.
                </p>
                <p>
                    When you use our Website, we collect and store your personal information 
                    which is provided by you from time to time. Our primary goal in doing so 
                    is to provide you a safe, efficient, smooth and customized experience. 
                    This allows us to provide services and features that most likely meet your needs,
                     and to customize our website to make your experience safer and easier. More importantly, 
                     while doing so, we collect 
                    personal information from you that we consider necessary for achieving this purpose.
                </p>
                <h5>Below are some of the ways in which we collect and store your information:</h5>
                <p>We receive and store any information you enter on our 
                    website or give us in any other way. We use the information that you provide for such purposes as responding to your requests,
                     customizing future shopping for you, improving our stores, and communicating with you.</p>
                    <p>We also store certain types of information whenever you interact with us. For example, like many websites, we use “cookies,” and we obtain certain types of information when your web browser accesses www.krishibidbazaar.com or advertisements
                         and other content served by or on behalf of www.krishibidbazaar.com on other websites.</p>
                    <p>To help us make e-mails more useful and interesting, we often receive a confirmation when you en e-mail from www.krishibidbazaar.com if your computer supports such capabilities.</p>
                    <p>Information about our customers is an important part of our business, and we are not in the business of selling it to others.</p>
                    <p>We release account and other personal information 
                        when we believe release is appropriate to comply with the law; enforce or apply our Terms of Use and other agreements; or protect the rights, property, or safety of www.krishibidbazaar.com, our users or others.
                         This includes exchanging information with other companies and organizations for fraud protection.</p>
                    <p>Krishibid Bazaar Ltd. reserves the right to change or update this policy at any time. Such changes shall be effective immediately upon posting to the Site.</p>
                    <h5>Data deletion request</h5>
                    <p>Krishibid Bazaar retains the following user data.</p>
                    <h5>Session</h5>
                    <p>The Session is retained for 30 days but User Data & Profile are retained for indefinite period. If you would like to delete your data from our website, please email us at</p>
                    <p>support@krishibidbazaar.com</p>
                    <p>Please mention “Data deletion” in subject line.</p>
                    <p>Thank you</p>
            </div>
        </div>
    </div>
</section>
<!-- error area end -->
@endsection