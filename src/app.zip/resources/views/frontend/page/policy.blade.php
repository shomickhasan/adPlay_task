@extends('frontend.main')
@section('ftitle', 'Return & Refund Policy')
@section('frontend')
    @push("css")
        <style>

        </style>
    @endpush
    {{--  <!--<section class="page__title p-relative d-flex align-items-center" data-background="{{asset('/')}}frontend/assets/img/page-title/page-title-2.jpg">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-xl-12">-->
    <!--                <div class="page__title-inner text-center">-->
    <!--                    <h1>Return & Refund Policy</h1>-->
    <!--                    <div class="page__title-breadcrumb">-->
    <!--                        <nav aria-label="breadcrumb">-->
    <!--                            <ol class="breadcrumb justify-content-center">-->
    <!--                                <li class="breadcrumb-item"><a href="">Home</a></li>-->
    <!--                                <li class="breadcrumb-item active" aria-current="page"> Return & Refund Policy</li>-->
    <!--                            </ol>-->
    <!--                        </nav>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->  --}}
    <section class="container mt-5">
        <div class="about-section">
            <h2 class="about-title">Return & Refund Policy</h2>
            <p class="about-text">
                At Haorerbazar, we strive to ensure that our customers are completely satisfied with their purchases. Our Return & Refund Policy is designed to provide you with a hassle-free experience.
            </p>

            <h3 class="about-title">Eligibility for Returns:</h3>
            <ul class="fish-list">
                <li><strong>Live Fish:</strong> Due to the perishable nature of live fish, returns are only accepted if the fish arrive in poor condition. Please contact us within 24 hours of delivery with photographic evidence.</li>
                <li><strong>Dried Fish:</strong> Returns are accepted if the product is damaged, spoiled, or not as described. Please contact us within 7 days of delivery with photographic evidence.</li>
            </ul>

            <h3 class="about-title">Return Process:</h3>
            <ul class="fish-list">
                <li><strong>Contact Us:</strong> Reach out to our customer service team via email at <a href="mailto:contact@haorerbazar.com">contact@haorerbazar.com</a> or call us at +880 1711-742983 with your order details and the reason for the return.</li>
                <li><strong>Provide Evidence:</strong> Share photographic evidence of the issue to help us understand the problem.</li>
                <li><strong>Return Approval:</strong> Once your return request is approved, we will provide instructions on how to return the product.</li>
            </ul>

            <h3 class="about-title">Refunds:</h3>
            <ul class="fish-list">
                <li><strong>Live Fish:</strong> If your return is approved, we will issue a full refund or send a replacement, based on your preference.</li>
                <li><strong>Dried Fish:</strong> Upon receiving the returned product, we will inspect it and process your refund within 7 business days. Refunds will be issued to the original payment method.</li>
            </ul>

            <h3 class="about-title">Non-Returnable Items:</h3>
            <ul class="fish-list">
                <li>Products that have been used or altered.</li>
                <li>Items without original packaging or proof of purchase.</li>
            </ul>

            <h3 class="about-title">Customer Satisfaction:</h3>
            <p class="about-text">
                Your satisfaction is our top priority. If you have any concerns or issues with your order, please do not hesitate to contact us. We are here to help and ensure that you have a positive experience with Haorerbazar.
            </p>

            <p class="about-text">
                Thank you for choosing Haorerbazar. We appreciate your trust in us and look forward to serving you again!
            </p>
        </div>
    </section>
    <section class="container mt-5 mb-3">
        <div class="about-section" style="margin-top: 20px; margin-bottom: 20px;">
            <h2 class="about-title">ফেরত এবং ফেরত নীতি</h2>
            <p class="about-text">
                হাওরেরবাজারে, আমরা নিশ্চিত করার চেষ্টা করি যে আমাদের গ্রাহকরা তাদের ক্রয়ের সাথে সম্পূর্ণ সন্তুষ্ট। আমাদের ফেরত এবং ফেরত নীতি আপনাকে ঝামেলামুক্ত অভিজ্ঞতা প্রদানের জন্য ডিজাইন করা হয়েছে।
            </p>

            <h3 class="about-title">ফেরত দেওয়ার যোগ্যতা:</h3>
            <ul class="fish-list">
                <li><strong>জীবন্ত মাছ:</strong> জীবন্ত মাছের পচনশীল প্রকৃতির কারণে, মাছটি খারাপ অবস্থায় পৌঁছালেই কেবল ফেরত গ্রহণ করা হয়। ডেলিভারির 24 ঘন্টার মধ্যে ফটোগ্রাফিক প্রমাণ সহ আমাদের সাথে যোগাযোগ করুন।</li>
                <li><strong>শুকনো মাছ:</strong> পণ্যটি ক্ষতিগ্রস্ত, নষ্ট, অথবা বর্ণিত হিসাবে না থাকলে ফেরত গ্রহণ করা হয়। ডেলিভারির 7 দিনের মধ্যে ফটোগ্রাফিক প্রমাণ সহ আমাদের সাথে যোগাযোগ করুন।</li>
            </ul>

            <h3 class="about-title">ফেরত প্রক্রিয়া:</h3>
            <ul class="fish-list">
                <li><strong>আমাদের সাথে যোগাযোগ করুন:</strong> <a href="mailto:contact@haorerbazar.com">contact@haorerbazar.com</a> ইমেলের মাধ্যমে আমাদের গ্রাহক পরিষেবা দলের সাথে যোগাযোগ করুন অথবা আপনার অর্ডারের বিবরণ এবং ফেরতের কারণ সহ +880 1711-742983 নম্বরে কল করুন।</li>
                <li><strong>প্রমাণ প্রদান করুন:</strong> সমস্যাটি বুঝতে আমাদের সাহায্য করার জন্য সমস্যার ফটোগ্রাফিক প্রমাণ শেয়ার করুন।</li>
                <li><strong>ফেরত অনুমোদন:</strong> আপনার ফেরতের অনুরোধ অনুমোদিত হয়ে গেলে, আমরা কীভাবে পণ্যটি ফেরত দিতে হবে তার নির্দেশাবলী প্রদান করব।</li>
            </ul>

            <h3 class="about-title">ফেরত:</h3>
            <ul class="fish-list">
                <li><strong>জীবন্ত মাছ:</strong> আপনার ফেরত অনুমোদিত হলে, আপনার পছন্দের উপর ভিত্তি করে আমরা সম্পূর্ণ ফেরত প্রদান করব অথবা প্রতিস্থাপন পাঠাবো।</li>
                <li><strong>শুকনো মাছ:</strong> ফেরত দেওয়া পণ্যটি পাওয়ার পর, আমরা এটি পরিদর্শন করব এবং ৭ কার্যদিবসের মধ্যে আপনার ফেরত প্রক্রিয়া করব। ফেরত মূল পেমেন্ট পদ্ধতিতে জারি করা হবে।</li>
            </ul>

            <h3 class="about-title">ফেরতযোগ্য নয় এমন আইটেম:</h3>
            <ul class="fish-list">
                <li>ব্যবহৃত বা পরিবর্তিত পণ্য।</li>
                <li>আসল প্যাকেজিং বা ক্রয়ের প্রমাণ ছাড়াই আইটেম।</li>
            </ul>

            <h3 class="about-title">গ্রাহক সন্তুষ্টি:</h3>
            <p class="about-text">
                আপনার সন্তুষ্টি আমাদের সর্বোচ্চ অগ্রাধিকার। আপনার অর্ডার নিয়ে যদি কোনও উদ্বেগ বা সমস্যা থাকে, তাহলে দয়া করে আমাদের সাথে যোগাযোগ করতে দ্বিধা করবেন না। হাওরেরবাজারের সাথে আপনার ইতিবাচক অভিজ্ঞতা নিশ্চিত করতে এবং সহায়তা করতে আমরা এখানে আছি।
            </p>

            <p class="about-text">
                হাওরেরবাজার বেছে নেওয়ার জন্য আপনাকে ধন্যবাদ। আমাদের উপর আপনার আস্থার জন্য আমরা কৃতজ্ঞ এবং আবার আপনাকে সেবা দেওয়ার জন্য উন্মুখ!
            </p>
        </div>
    </section>







@endsection
